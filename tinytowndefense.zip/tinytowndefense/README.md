## Notes

Thanks to [ZeFrost](https://itch.io/profile/zefrost) for creating this great game and which you can download for free on [itch.io](https://zefrost.itch.io/tiny-town-defense)

Requires the Linux Version of the game Tiny\_Town\_Defense.x86\_64

**Notes:** 

- Place file into /ports/tinytowndefense/gamedata folder.

## Controls

| Button        | Action             |
| ------------- | -------------------|
| D-PAD         | Movement           |
| L-STICK (L/R) | Mouse/Movement     |
| B             | Jump               |
| SELECT        | Pause/Menu         |
| START         | Enter/Select Option|