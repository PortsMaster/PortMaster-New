#ifndef	_copyfile_h_
#define	_copyfile_h_

void copyfile (char *source,char *dest);


#endif // _copyfile_h_