#ifndef	_pixwrite_h_
#define	_pixwrite_h_

void pixwrite (int n);

#endif // _pixwrite_h_