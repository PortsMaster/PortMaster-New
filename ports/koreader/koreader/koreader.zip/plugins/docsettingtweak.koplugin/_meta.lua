local _ = require("gettext")
return {
    name = "docsettingtweak",
    fullname = _("Tweak document settings"),
    description = _([[This plugin allows you to tweak document settings before the document is loaded based on external factors.]]),
}
