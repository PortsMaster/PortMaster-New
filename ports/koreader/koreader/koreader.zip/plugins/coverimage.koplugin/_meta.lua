local _ = require("gettext")
return {
    name = "coverimage",
    fullname = _("Cover image"),
    description = _([[Stores cover image to a file.]]),
}
