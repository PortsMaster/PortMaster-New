local _ = require("gettext")
return {
    name = "externalkeyboard",
    fullname = _("External keyboard"),
    description = _([[Manages USB OTG and configures keyboard.]]),
}
