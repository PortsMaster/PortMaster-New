local _ = require("gettext")
return {
    name = "hotkeys",
    fullname = _("Hotkeys"),
    description = _([[This plugin provides custom shortcut support for devices with physical keys.]]),
}
