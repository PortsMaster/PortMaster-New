-- PluginShare is a table for plugins to exchange data between each other.
-- It is a singleton, which will persist across views (and, as such, across plugins lifecycle).
-- Plugins should maintain their own protocols.
return {}
