MCL_Villages:
============================
A fork of Rochambeau's "Settlements" mod converted for use in MineClone2.

--------------
Using the mod:
--------------
This mod adds settlements on world generation.

And, in Creative Mode; also comes with a debug tool for spawning in villages.


-------------
MCL2 Credits:
-------------
Code forked from: https://github.com/MysticTempest/settlements/tree/mcl_villages
	Commit: e24b4be
================================================================================
Basic conversion of Settlements mod for compatibility with MineClone2, plus new schematics: MysticTempest

Seed-based Village Generation, multi-threading, bugfixes: kay27



=========================
version: 0.1 alpha

License of source code: WTFPL
-----------------------------
(c) Copyright Rochambeau (2018)

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.


Credits:
--------------
This mod is based on "ruins" by BlockMen

Completely new schematics for MineClone2:
MysticTempest - CC-BY-SA 4.0

