mcl_minecarts
=============
Based on the mod "boost_carts" by Krock.
Target: Run smoothly and do not use too much CPU.

License of source code:
-----------------------
MIT License

Copyright (C) 2012-2016 PilzAdam
Copyright (C) 2014-2016 SmallJoker
Copyright (C) 2012-2016 Various Minetest developers and contributors

Authors/licenses of media files:
-----------------------

Minecart model:
  22i (GPLv3)

Texture files (CC BY-SA 3.0):
  XSSheep
