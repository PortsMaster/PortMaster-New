License of Code
----------------

Author: TheRandomLegoBrick
License: GPLv3
See https://www.gnu.org/licenses/gpl-3.0.en.html for further information


License of Media (textures & sounds)
-------------------------------------

Author: TheRandomLegoBrick
Liscense: CC0 1.0 Universal (CC0 1.0) 
Files:
	mud_footsteps.ogg
	mud_place_dug.ogg
	mcl_mud_bricks.png
	mcl_mud_packed_mud.png
	mcl_mud.png

See https://creativecommons.org/publicdomain/zero/1.0/legalcode for further information