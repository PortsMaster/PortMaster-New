mcl_ocean = {}

-- Prismarine (includes sea lantern)
dofile(minetest.get_modpath(minetest.get_current_modname()).."/prismarine.lua")

-- Corals
dofile(minetest.get_modpath(minetest.get_current_modname()).."/corals.lua")

-- Seagrass
dofile(minetest.get_modpath(minetest.get_current_modname()).."/seagrass.lua")

-- Kelp
dofile(minetest.get_modpath(minetest.get_current_modname()).."/kelp.lua")

-- Sea Pickle
dofile(minetest.get_modpath(minetest.get_current_modname()).."/sea_pickle.lua")
