local path = minetest.get_modpath("mcl_fireworks")

dofile(path .. "/register.lua")
dofile(path .. "/crafting.lua")