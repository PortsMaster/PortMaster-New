# Crafting Guide (MineClone 2 edition)

#### `mcl_craftguide` is based on, `craftguide` the most comprehensive crafting guide on Minetest.
#### Consult the [Minetest Wiki](http://wiki.minetest.net/Crafting_guide) for more details.

This crafting guide can be accessed from the invenotory menu (book icon).

Crafting guide starts out empty and will be filled with more recipes whenever you hold on
to a new items that you can use to new recipes.

For developers, there's a modding API (see `API.md`).
