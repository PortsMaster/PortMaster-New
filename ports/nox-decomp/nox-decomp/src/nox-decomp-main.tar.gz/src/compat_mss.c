#ifdef __APPLE__
#include <OpenAL/al.h>
#include <OpenAL/alc.h>
#else
#include <AL/al.h>
#include <AL/alc.h>
#endif
#include <SDL2/SDL.h>

#define MINIMP3_ONLY_MP3
#define MINIMP3_NO_SIMD
#define MINIMP3_IMPLEMENTATION
#include "minimp3.h"

#include "defs.h"

#if defined(_WIN32) && defined(USE_SDL)
#include <stdio.h>

void nox_dbgbreak_impl(const char *file, int line, const char *func)
{
    fprintf(stderr, "[AIL] DebugBreak suppressed at %s:%d (%s)\n", file, line, func);
    fflush(stderr);
}
#endif

struct _DIG_DRIVER
{
    ALCdevice *device;
    ALCcontext *context;
    SDL_mutex *mutex;
    HSAMPLE sample_head;
    HSTREAM stream_head;
};

struct _SAMPLE_BUFFER
{
    const void *buffer;
    unsigned int length;
    unsigned int position;
};

struct _SAMPLE
{
    HDIGDRIVER dig;

    HSAMPLE next;
    ALuint source;
    ALuint hwbuf[2];
    BYTE hwready;

    struct _SAMPLE_BUFFER buffers[2];
    BYTE current;
    BYTE ready;

    BYTE stereo;
    BYTE adpcm;

    unsigned int playback_rate;
    unsigned int block_size;

    unsigned int playing;

    AILSAMPLECB eob;
    AILSAMPLECB eos;
    S32 user[8];
};

struct _STREAM
{
    HDIGDRIVER dig;

    HSTREAM next;
    ALuint source;
    ALuint hwbuf[2];
    BYTE hwready;

    BYTE stereo;
    unsigned int playback_rate;
    unsigned int playing;
    
    FILE *file;
    unsigned int file_size;
    unsigned int chunk_size;
    unsigned int chunk_pos;
    unsigned int buffered;
    union
    {
        struct
        {
            WAVEFORMAT wf;
            unsigned int position;
        } pcm;
        struct
        {
            WAVEFORMAT wf;
            unsigned int position;
            unsigned int samples;
        } adpcm;
        struct 
        {
            MPEGLAYER3WAVEFORMAT wf;
            mp3dec_t dec;
        } mp3;
    };

    /* Decoded PCM cached when ADPCM seek lands in the middle of a block */
    int16_t adpcm_seek_pcm[16 * 1024 * 2];
    unsigned int adpcm_seek_pcm_samples;
    unsigned int adpcm_seek_pcm_pos;

    unsigned int (*decode)(HSTREAM, int16_t *, unsigned int);
    void (*seek)(HSTREAM, unsigned int);
    unsigned int (*tell)(HSTREAM);
    BYTE buffer[16 * 1024];
};

struct _TIMER
{
    unsigned int interval;
    AILTIMERCB cb;
    U32 user;
};

// https://wiki.multimedia.cx/index.php/IMA_ADPCM
int ima_index_table[16] = {
    -1, -1, -1, -1, 2, 4, 6, 8,
    -1, -1, -1, -1, 2, 4, 6, 8
}; 

int ima_step_table[89] = { 
    7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 
    19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 
    50, 55, 60, 66, 73, 80, 88, 97, 107, 118, 
    130, 143, 157, 173, 190, 209, 230, 253, 279, 307,
    337, 371, 408, 449, 494, 544, 598, 658, 724, 796,
    876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066, 
    2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358,
    5894, 6484, 7132, 7845, 8630, 9493, 10442, 11487, 12635, 13899, 
    15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794, 32767 
}; 

static inline int16_t sat16(int x)
{
    if (x < INT16_MIN)
        return INT16_MIN;
    else if (x > INT16_MAX)
        return INT16_MAX;
    else
        return x;
}

static inline int satindex(int x)
{
    if (x < 0)
        return 0;
    else if (x > 88)
        return 88;
    else
        return x;
}

static int16_t decode_nibble(int16_t predictor, unsigned int nibble, int unsigned index)
{
    int diff, step = ima_step_table[index];

    diff = step >> 3;
    if (nibble & 4) diff += step;
    if (nibble & 2) diff += step >> 1;
    if (nibble & 1) diff += step >> 2;
    if (nibble & 8)
        predictor = sat16(predictor - diff);
    else
        predictor = sat16(predictor + diff);
    return predictor;
}

static unsigned int decode_adpcm(int16_t *out, const BYTE *data, unsigned int size)
{
    int index, diff;
    unsigned int i, samples = 0;
    int8_t nibble, sign;
    int16_t predictor;

    predictor = data[0] | (data[1] << 8);
    index = data[2];
    index = satindex(index);

    out[samples++] = predictor;

    for (i = 4; i < size; i++)
    {
        unsigned int b  = (unsigned int)data[i];
        unsigned int n0 = b & 0x0Fu;          // low nibble
        unsigned int n1 = (b >> 4) & 0x0Fu;   // high nibble

        predictor = decode_nibble(predictor, n0, index);
        index = satindex(index + ima_index_table[n0]);
        out[samples++] = predictor;

        predictor = decode_nibble(predictor, n1, index);
        index = satindex(index + ima_index_table[n1]);
        out[samples++] = predictor;
    }

    return samples;
}

static unsigned int decode_adpcm_stereo(int16_t *out, const BYTE *data, unsigned int size)
{
    int lindex, rindex, diff;
    unsigned int i, samples = 0;
    int8_t nibble, sign;
    int16_t lpredictor, rpredictor;

    lpredictor = data[0] | (data[1] << 8);
    lindex = data[2];
    lindex = satindex(lindex);
    rpredictor = data[4] | (data[5] << 8);
    rindex = data[6];
    rindex = satindex(rindex);

    out[samples++] = lpredictor;
    out[samples++] = rpredictor;

    for (i = 8; i + 7 < size; i += 8)
    {
        unsigned int j;

        for (j = 0; j < 4; j++)
        {
            unsigned int bl  = (unsigned int)data[i + j];
            unsigned int br  = (unsigned int)data[i + j + 4];
            unsigned int l0  = bl & 0x0Fu;
            unsigned int l1  = (bl >> 4) & 0x0Fu;
            unsigned int r0  = br & 0x0Fu;
            unsigned int r1  = (br >> 4) & 0x0Fu;

            lpredictor = decode_nibble(lpredictor, l0, lindex);
            lindex = satindex(lindex + ima_index_table[l0]);
            out[samples++] = lpredictor;

            rpredictor = decode_nibble(rpredictor, r0, rindex);
            rindex = satindex(rindex + ima_index_table[r0]);
            out[samples++] = rpredictor;

            lpredictor = decode_nibble(lpredictor, l1, lindex);
            lindex = satindex(lindex + ima_index_table[l1]);
            out[samples++] = lpredictor;

            rpredictor = decode_nibble(rpredictor, r1, rindex);
            rindex = satindex(rindex + ima_index_table[r1]);
            out[samples++] = rpredictor;
        }
    }

    return samples;
}

static void checkError()
{
    ALenum error = alGetError();
    if (error != AL_NO_ERROR)
    {
        const ALchar *estr = alGetString(error);
        fprintf(stderr, "[AIL] OpenAL error: 0x%x (%s)\n", (unsigned)error, estr ? estr : "unknown");
        fflush(stderr);
        /* Do not hard-break under Wine/SDL; keep going so we can see follow-up failures */
        /* DebugBreak(); */
    }
}

static void sample_unqueue_buffers(HSAMPLE S)
{
    ALint processed = 0;
    alGetSourcei(S->source, AL_BUFFERS_PROCESSED, &processed);
    checkError();

    if (processed <= 0) return;
    if (processed > 2) processed = 2; // paranoia

    ALuint tmp[2];
    alSourceUnqueueBuffers(S->source, processed, tmp);
    checkError();

    for (int i = 0; i < processed; i++) {
        if (S->hwready < 2)
            S->hwbuf[S->hwready++] = tmp[i];
        // else: drop on floor to avoid overflow (better than corrupting memory)
    }
}

static void sample_drain_buffers(HSAMPLE S)
{
    ALint queued = 0;
    alGetSourcei(S->source, AL_BUFFERS_QUEUED, &queued);
    checkError();

    if (queued <= 0) return;
    if (queued > 2) queued = 2;

    ALuint tmp[2];
    alSourceUnqueueBuffers(S->source, queued, tmp);
    checkError();

    for (int i = 0; i < queued; i++) {
        if (S->hwready < 2)
            S->hwbuf[S->hwready++] = tmp[i];
    }
}

static void stream_unqueue_buffers(HSTREAM S)
{
    ALint processed = 0;
    alGetSourcei(S->source, AL_BUFFERS_PROCESSED, &processed);
    checkError();

    if (processed <= 0) return;
    if (processed > 2) processed = 2;

    ALuint tmp[2];
    alSourceUnqueueBuffers(S->source, processed, tmp);
    checkError();

    for (int i = 0; i < processed; i++) {
        if (S->hwready < 2)
            S->hwbuf[S->hwready++] = tmp[i];
    }
}

DXDEC HSAMPLE AILCALL AIL_allocate_sample_handle (HDIGDRIVER dig)
{
    HSAMPLE sample = calloc(1, sizeof(*sample));
    sample->dig = dig;
    // fprintf(stderr, "%s\n", __FUNCTION__);

    alGenSources(1, &sample->source);
    checkError();
    alGenBuffers(2, sample->hwbuf);
    checkError();
    sample->hwready = 2;

    SDL_LockMutex(dig->mutex);
    sample->next = dig->sample_head;
    dig->sample_head = sample;
    SDL_UnlockMutex(dig->mutex);
    return sample;
}

static void sample_eos(HSAMPLE S)
{
    S->playing = 0;
    if (S->eos)
        S->eos(S);
}

static void sample_eob(HSAMPLE S)
{
    S->ready++;
    S->current = !S->current;
    if (S->eob)
        S->eob(S);
}

DXDEC void AILCALL AIL_close_stream(HSTREAM stream)
{
    HSTREAM *pp;

    if (!stream)
        return;

    SDL_LockMutex(stream->dig->mutex);

    stream->playing = 0;

    if (stream->source)
    {
        alSourceStop(stream->source);

        ALint queued = 0;
        alGetSourcei(stream->source, AL_BUFFERS_QUEUED, &queued);
        if (queued > 2) queued = 2;
        if (queued > 0)
        {
            ALuint tmp[2];
            alSourceUnqueueBuffers(stream->source, queued, tmp);
        }
    }

    pp = &stream->dig->stream_head;
    while (*pp && *pp != stream)
        pp = &(*pp)->next;
    if (*pp == stream)
        *pp = stream->next;

    SDL_UnlockMutex(stream->dig->mutex);

    if (stream->source)
        alDeleteSources(1, &stream->source);
    if (stream->hwbuf[0] || stream->hwbuf[1])
        alDeleteBuffers(2, stream->hwbuf);

    if (stream->file)
        fclose(stream->file);

    free(stream);
}

DXDEC void AILCALL AIL_digital_configuration (HDIGDRIVER dig, S32 FAR *rate, S32 FAR *format, char FAR *string)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    if (string)
        strcpy(string, "");
}

DXDEC S32 AILCALL AIL_digital_handle_release(HDIGDRIVER drvr)
{
    if (!drvr)
        return 0;

    /* stop audio so Miles-style "release" actually quiets the system */
    SDL_LockMutex(drvr->mutex);

    for (HSAMPLE s = drvr->sample_head; s; s = s->next) {
        if (s->source) {
            alSourceStop(s->source);
        }
        s->playing = 0;
        /* optional: drain queued buffers so next play starts clean */
        if (s->source) {
            sample_drain_buffers(s);
        }
    }

    for (HSTREAM st = drvr->stream_head; st; st = st->next) {
        if (st->source) {
            alSourceStop(st->source);
        }
        st->playing = 0;
        /* optional: unqueue anything we can */
        if (st->source) {
            /* drain: unqueue queued buffers (mirrors sample_drain_buffers) */
            ALint queued = 0;
            alGetSourcei(st->source, AL_BUFFERS_QUEUED, &queued);
            if (queued > 2) queued = 2;
            if (queued > 0) {
                ALuint tmp[2];
                alSourceUnqueueBuffers(st->source, queued, tmp);
                for (int i = 0; i < queued; i++) {
                    if (st->hwready < 2) st->hwbuf[st->hwready++] = tmp[i];
                }
            }
        }
    }

    SDL_UnlockMutex(drvr->mutex);

    /* swallow errors; this is a compatibility shim */
    (void)alGetError();
    return 0;
}

DXDEC S32 AILCALL AIL_digital_handle_reacquire(HDIGDRIVER drvr)
{
    if (!drvr)
        return 0;

    /* Nothing to do in this backend; we never actually released the device/context.
       Returning success + clearing the game's "released" flag is what it expects. */
    return 0;
}

DXDEC void AILCALL AIL_end_sample (HSAMPLE S)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);

    SDL_LockMutex(S->dig->mutex);
    if (S->playing)
    {
        sample_eob(S);
        sample_eos(S);
    }
    SDL_UnlockMutex(S->dig->mutex);
}

DXDEC S32 AILCALL AIL_get_preference (U32 number)
{
    // fprintf(stderr, "%s: %d\n", __FUNCTION__, number);
    return 0;
}

DXDEC void AILCALL AIL_init_sample (HSAMPLE S)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    SDL_LockMutex(S->dig->mutex);

    S->current = 0;
    S->ready = 2;
    alSourcef(S->source, AL_PITCH, 1.0f);
    alSourcef(S->source, AL_GAIN, 1.0f);
    AIL_set_sample_pan(S, 63);

    S->playing = 0;
    alSourceStop(S->source);
    sample_drain_buffers(S);

    SDL_UnlockMutex(S->dig->mutex);
}

DXDEC char FAR *AILCALL AIL_last_error (void)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    DebugBreak();
    return 0;
}

DXDEC void AILCALL AIL_load_sample_buffer (HSAMPLE S, U32 buff_num, void const FAR *buffer, U32 len)
{
    struct _SAMPLE_BUFFER *sb = &S->buffers[buff_num];
    // fprintf(stderr, "%s: %08X, %d, %08X, %d\n", __FUNCTION__, (int)S, buff_num, (int)buffer, len);
    SDL_LockMutex(S->dig->mutex);
    sb->buffer = buffer;
    sb->length = len;
    sb->position = 0;
    S->playing = 1;
    SDL_UnlockMutex(S->dig->mutex);
}

static void stream_find_data(HSTREAM stream)
{
    char tmp[8];

    stream->chunk_size = 0;
    stream->chunk_pos = 0;

    while (ftell(stream->file) < stream->file_size)
    {
        unsigned int size;
        if (fread(tmp, 8, 1, stream->file) != 1)
            break;
        size = *(DWORD *)(tmp + 4);
        unsigned int skip = size + (size & 1u); // RIFF chunks are padded to even size
        if (memcmp(tmp, "data", 4) == 0)
        {
            stream->chunk_size = size;
            stream->chunk_pos = 0;
            break;
        }
        fseek(stream->file, skip, SEEK_CUR);
    }
}

static unsigned int stream_pcm_decode(HSTREAM stream, int16_t *out, unsigned int max_samples)
{
    unsigned int channels = stream->stereo ? 2 : 1;
    unsigned int remaining = stream->chunk_size - stream->chunk_pos;

    if (!remaining)
    {
        stream_find_data(stream);
        remaining = stream->chunk_size - stream->chunk_pos;
        if (!remaining)
        {
            stream->playing = 0;
            return 0;
        }
    }

    if (remaining / 2 >= max_samples)
        remaining = max_samples * 2;

    size_t got = fread(out, 2 * channels, remaining / (2 * channels), stream->file);
    stream->chunk_pos += (unsigned int)(got * 2 * channels);
    stream->pcm.position += (unsigned int)got;
    return (unsigned int)got * channels;
}

static void stream_pcm_seek(HSTREAM stream, unsigned int position)
{
    // TODO
    stream->pcm.position = 0;
}

static unsigned int stream_pcm_tell(HSTREAM stream)
{
    return stream->pcm.position;
}

static unsigned int stream_adpcm_decode(HSTREAM stream, int16_t *out, unsigned int max_samples)
{
    unsigned int block_size = stream->adpcm.wf.nBlockAlign;
    unsigned int samples;
    unsigned int channels = stream->stereo ? 2 : 1;

    if (stream->adpcm_seek_pcm_pos < stream->adpcm_seek_pcm_samples)
    {
        unsigned int available = stream->adpcm_seek_pcm_samples - stream->adpcm_seek_pcm_pos;
        unsigned int to_copy = available;

        if (to_copy > max_samples)
            to_copy = max_samples;

        memcpy(out,
               stream->adpcm_seek_pcm + stream->adpcm_seek_pcm_pos,
               to_copy * sizeof(int16_t));

        stream->adpcm_seek_pcm_pos += to_copy;

        if (stream->adpcm_seek_pcm_pos >= stream->adpcm_seek_pcm_samples)
        {
            stream->adpcm_seek_pcm_pos = 0;
            stream->adpcm_seek_pcm_samples = 0;
        }

        return to_copy;
    }

    if (stream->adpcm.position >= stream->adpcm.samples)
    {
        stream->playing = 0;
        return 0;
    }

    if (stream->buffered < block_size)
    {
        unsigned int remaining = stream->chunk_size - stream->chunk_pos;

        if (!remaining)
        {
            stream_find_data(stream);
            remaining = stream->chunk_size - stream->chunk_pos;
            if (!remaining)
            {
                stream->playing = 0;
                return 0;
            }
        }
        
        if (remaining > block_size - stream->buffered)
            remaining = block_size - stream->buffered;
        fread(stream->buffer + stream->buffered, 1, remaining, stream->file);
        stream->buffered += remaining;
        stream->chunk_pos += remaining;
    }

    if (stream->stereo)
        samples = decode_adpcm_stereo(out, stream->buffer, block_size);
    else
        samples = decode_adpcm(out, stream->buffer, block_size);

    stream->buffered -= block_size;
    if (stream->buffered)
        memmove(stream->buffer, stream->buffer + block_size, stream->buffered);
    if (samples / channels + stream->adpcm.position >= stream->adpcm.samples)
        samples = (stream->adpcm.samples - stream->adpcm.position) * channels;
    stream->adpcm.position += samples / channels;
    return samples;
}

static void stream_adpcm_seek(HSTREAM stream, unsigned int position)
{
    unsigned int block_size = stream->adpcm.wf.nBlockAlign;
    unsigned int channels = stream->stereo ? 2 : 1;
    unsigned int samples_per_block = (block_size / channels - 4) * 2;
    unsigned int target_block;
    unsigned int intra_block_samples;
    unsigned int remaining_position;
    int16_t tmp[16 * 1024 * 2];
    unsigned int decoded_samples;
    unsigned int skip_samples;
    unsigned int keep_samples;

    stream->buffered = 0;
    stream->chunk_size = 0;
    stream->chunk_pos = 0;
    stream->adpcm.position = 0;
    stream->adpcm_seek_pcm_samples = 0;
    stream->adpcm_seek_pcm_pos = 0;

    if (samples_per_block == 0)
        return;

    target_block = position / samples_per_block;
    intra_block_samples = position % samples_per_block;
    remaining_position = target_block;

    /* Walk data chunks until we reach the chunk containing the target block */
    for (;;)
    {
        unsigned int chunk_blocks;

        stream_find_data(stream);
        if (stream->chunk_size == 0)
            return;

        chunk_blocks = stream->chunk_size / block_size;

        if (remaining_position < chunk_blocks)
        {
            /* Target block is inside this chunk */
            fseek(stream->file, (long)(remaining_position * block_size), SEEK_CUR);
            stream->chunk_pos += remaining_position * block_size;
            stream->adpcm.position += remaining_position * samples_per_block;
            break;
        }

        /* Skip whole chunk */
        fseek(stream->file, (long)stream->chunk_size, SEEK_CUR);
        stream->adpcm.position += chunk_blocks * samples_per_block;
        remaining_position -= chunk_blocks;
    }

    /* Exact block boundary seek: done */
    if (intra_block_samples == 0)
        return;

    /* Read and decode the target block, then cache the remaining PCM after the intra-block offset */
    if (stream->chunk_pos + block_size > stream->chunk_size)
        return;

    if (fread(stream->buffer, 1, block_size, stream->file) != block_size)
        return;

    stream->chunk_pos += block_size;

    if (stream->stereo)
        decoded_samples = decode_adpcm_stereo(tmp, stream->buffer, block_size);
    else
        decoded_samples = decode_adpcm(tmp, stream->buffer, block_size);

    skip_samples = intra_block_samples * channels;
    if (skip_samples > decoded_samples)
        skip_samples = decoded_samples;

    keep_samples = decoded_samples - skip_samples;
    if (keep_samples > 0)
        memcpy(stream->adpcm_seek_pcm, tmp + skip_samples, keep_samples * sizeof(int16_t));

    stream->adpcm_seek_pcm_samples = keep_samples;
    stream->adpcm_seek_pcm_pos = 0;
    stream->adpcm.position += intra_block_samples;
}

static unsigned int stream_adpcm_tell(HSTREAM stream)
{
    return stream->adpcm.position;
}

static unsigned int stream_mp3_decode(HSTREAM stream, int16_t *out, unsigned int max_samples)
{
    unsigned int remaining = stream->chunk_size - stream->chunk_pos;
    unsigned int samples;
    mp3dec_frame_info_t info;

    if (stream->buffered < sizeof(stream->buffer))
    {
        if (!remaining && !stream->buffered)
        {
find_data:
            stream_find_data(stream);
            remaining = stream->chunk_size - stream->chunk_pos;
            if (!remaining)
            {
                stream->playing = 0;
                return 0;
            }
        }
        
read_data:
        if (remaining)
        {
            if (remaining > sizeof(stream->buffer) - stream->buffered)
                remaining = sizeof(stream->buffer) - stream->buffered;
            fread(stream->buffer + stream->buffered, 1, remaining, stream->file);
            stream->buffered += remaining;
            stream->chunk_pos += remaining;
        }
    }

    samples = mp3dec_decode_frame(&stream->mp3.dec, stream->buffer, stream->buffered, out, &info);
    if (samples == 0)
    {
        if (remaining)
            goto read_data;
        else
            goto find_data;
    }

    stream->buffered -= info.frame_bytes;
    if (stream->buffered)
        memmove(stream->buffer, stream->buffer + info.frame_bytes, stream->buffered);

    return samples * (stream->stereo ? 2u : 1u);
}

static void stream_mp3_seek(HSTREAM stream, unsigned int position)
{
    (void)position;
    mp3dec_init(&stream->mp3.dec);

    stream->buffered = 0;
    stream->chunk_pos = 0;
    stream->chunk_size = 0; // force stream_find_data() on next decode
}

static unsigned int stream_mp3_tell(HSTREAM steam)
{
    return 0;
}

DXDEC HSTREAM AILCALL AIL_open_stream(HDIGDRIVER dig, char const FAR * filename, S32 stream_mem)
{
    unsigned int file_size, size;
    BYTE tmp[256];
    FILE *f;
    HSTREAM stream = NULL;
    WAVEFORMAT *wf = (WAVEFORMAT *)tmp;

    f = fopen(filename, "rb");
    if (f == NULL)
        return NULL;

    if (fread(tmp, 12, 1, f) != 1)
        goto error;

    if (memcmp(tmp, "RIFF", 4) != 0)
        goto error;

    // XXX ignore file size?
    file_size = *(DWORD *)(tmp + 4) + 8; // RIFF size excludes the first 8 bytes

    if (memcmp(tmp + 8, "WAVE", 4) != 0)
        goto error;

    if (fread(tmp, 8, 1, f) != 1)
        goto error;
    size = *(DWORD *)(tmp + 4);

    if (memcmp(tmp, "fmt ", 4) != 0)
        goto error;

    if (size < sizeof(WAVEFORMAT) || size > sizeof(tmp))
        goto error;

    if (fread(tmp, size, 1, f) != 1)
        goto error;

    fprintf(stderr,
            "[AIL] open_stream %s: fmt=0x%04X channels=%u rate=%u avgbytes=%u blockalign=%u fmt_size=%u\n",
            filename,
            (unsigned)wf->wFormatTag,
            (unsigned)wf->nChannels,
            (unsigned)wf->nSamplesPerSec,
            (unsigned)wf->nAvgBytesPerSec,
            (unsigned)wf->nBlockAlign,
            size);
    fflush(stderr);

    stream = calloc(1, sizeof(*stream));
    stream->dig = dig;
    stream->file = f;
    stream->file_size = file_size;

    if (wf->wFormatTag == 0x01) // PCM
    {
        stream->playback_rate = wf->nSamplesPerSec;
        stream->stereo = wf->nChannels > 1;
        stream->pcm.wf = *wf;
        stream->decode = stream_pcm_decode;
        stream->seek = stream_pcm_seek;
        stream->tell = stream_pcm_tell;
    }
    else if (wf->wFormatTag == 0x11) // ADPCM
    {
        stream->playback_rate = wf->nSamplesPerSec;
        stream->stereo = wf->nChannels > 1;
        stream->adpcm.wf = *wf;
        stream->decode = stream_adpcm_decode;
        stream->seek = stream_adpcm_seek;
        stream->tell = stream_adpcm_tell;

        if (fread(tmp, 8, 1, f) != 1)
            goto error;
        if (memcmp(tmp, "fact", 4) != 0)
            goto error;
        size = *(DWORD *)(tmp + 4);
        if (size != 4)
            goto error;
        if (fread(tmp, 4, 1, f) != 1)
            goto error;

        stream->adpcm.samples = *(DWORD *)tmp;
    }
    else if (wf->wFormatTag == 0x55) // MP3 in WAV
    {
        unsigned int channels;
        unsigned int rate;
        unsigned int cbSize;

        /* Parse manually from the fmt chunk bytes.
           Offsets are standard WAVEFORMATEX/MPEGLAYER3WAVEFORMAT layout:
             0  WORD  wFormatTag
             2  WORD  nChannels
             4  DWORD nSamplesPerSec
             8  DWORD nAvgBytesPerSec
             12 WORD  nBlockAlign
             14 WORD  wBitsPerSample
             16 WORD  cbSize
             18 WORD  wID
             20 DWORD fdwFlags
             24 WORD  nBlockSize
             26 WORD  nFramesPerBlock
             28 WORD  nCodecDelay
        */
        if (size < 30)
            goto error;

        channels = *(WORD *)(tmp + 2);
        rate     = *(DWORD *)(tmp + 4);
        cbSize   = *(WORD *)(tmp + 16);

        fprintf(stderr,
                "[AIL] mp3-wav %s: channels=%u rate=%u cbSize=%u fmt_size=%u\n",
                filename, channels, rate, cbSize, size);
        fflush(stderr);

        if (cbSize != 12)
            goto error;

        stream->playback_rate = rate;
        stream->stereo = channels > 1;
        mp3dec_init(&stream->mp3.dec);
        stream->decode = stream_mp3_decode;
        stream->seek = stream_mp3_seek;
        stream->tell = stream_mp3_tell;
    }
    else
    {
        fprintf(stderr,
                "[AIL] unsupported WAV format in %s: fmt=0x%04X channels=%u rate=%u avgbytes=%u blockalign=%u fmt_size=%u\n",
                filename,
                (unsigned)wf->wFormatTag,
                (unsigned)wf->nChannels,
                (unsigned)wf->nSamplesPerSec,
                (unsigned)wf->nAvgBytesPerSec,
                (unsigned)wf->nBlockAlign,
                size);
        fflush(stderr);
        goto error;
    }

    alGenSources(1, &stream->source);
    checkError();
    alGenBuffers(2, stream->hwbuf);
    checkError();
    stream->hwready = 2;

    SDL_LockMutex(dig->mutex);
    stream->next = dig->stream_head;
    dig->stream_head = stream;
    SDL_UnlockMutex(dig->mutex);

    return stream;

error:
    fclose(f);
    free(stream);
    return NULL;
}

DXDEC void AILCALL AIL_pause_stream(HSTREAM stream, S32 onoff)
{
    if (!stream)
        return;

    SDL_LockMutex(stream->dig->mutex);

    if (onoff)
    {
        /* pause */
        stream->playing = 0;
        if (stream->source)
            alSourcePause(stream->source);
    }
    else
    {
        /* resume */
        stream->playing = 1;
        if (stream->source)
        {
            ALint state = 0;
            alGetSourcei(stream->source, AL_SOURCE_STATE, &state);
            if (state != AL_PLAYING)
                alSourcePlay(stream->source);
        }
    }

    SDL_UnlockMutex(stream->dig->mutex);

    /* Don’t fatal-break on OpenAL issues under Wine; just report via checkError */
    checkError();
}

DXDEC AILSAMPLECB AILCALL AIL_register_EOB_callback (HSAMPLE S, AILSAMPLECB EOB)
{
    AILSAMPLECB prev = S->eob;
    // fprintf(stderr, "%s: %08X, %08X\n", __FUNCTION__, (int)S, (int)EOB);
    S->eob = EOB;
    return prev;
}

DXDEC AILSAMPLECB AILCALL AIL_register_EOS_callback (HSAMPLE S, AILSAMPLECB EOS)
{
    AILSAMPLECB prev = S->eos;
    // fprintf(stderr, "%s: %08X, %08X\n", __FUNCTION__, (int)S, (int)EOS);
    S->eos = EOS;
    return prev;
}

DXDEC HTIMER AILCALL AIL_register_timer (AILTIMERCB fn)
{
    HTIMER timer = calloc(1, sizeof(*timer));
    // fprintf(stderr, "%s %08x\n", __FUNCTION__, (int)fn);
    timer->cb = fn;
    return timer;
}

DXDEC void AILCALL AIL_release_sample_handle (HSAMPLE S)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    DebugBreak();
}

DXDEC void AILCALL AIL_release_timer_handle (HTIMER timer)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    DebugBreak();
}

DXDEC void AILCALL AIL_resume_sample (HSAMPLE S)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    DebugBreak();
}

DXDEC S32 AILCALL AIL_sample_buffer_ready (HSAMPLE S)
{
    // fprintf(stderr, "%s: %08X\n", __FUNCTION__, (int)S);
    if (S->ready == 0)
        return -1;
    else if (S->ready-- == 2)
        return 0;
    return !S->current;
}

DXDEC S32 AILCALL AIL_sample_user_data (HSAMPLE S, U32 index)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    return S->user[index];
}

DXDEC void AILCALL AIL_serve(void)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
}

DXDEC S32 AILCALL AIL_set_preference (U32 number, S32 value)
{
    // fprintf(stderr, "%s: %d = %d\n", __FUNCTION__, number, value);
    return 0;
}

DXDEC void AILCALL AIL_set_sample_adpcm_block_size(HSAMPLE S, U32 blocksize)
{
    // Miles should always set this; but be defensive.
    if (blocksize < (S->stereo ? 8u : 4u)) blocksize = (S->stereo ? 8u : 4u);
    if (blocksize > 2048u) blocksize = 2048u; // keep decoded[] safe
    S->block_size = blocksize;
}

DXDEC void AILCALL AIL_set_sample_pan (HSAMPLE S, S32 pan)
{
    float pos[3] = { (pan - 63) / 64.0f, 0, 0 };
    pos[2] = sqrtf(1 - pos[0] * pos[0]);
    alSourcefv(S->source, AL_POSITION, pos);
    // fprintf(stderr, "%d -> %f, %f, %f\n", pan, pos[0], pos[1], pos[2]);
    // fprintf(stderr, "%s: %08X, %d\n", __FUNCTION__, (int)S, pan);
}

DXDEC void AILCALL AIL_set_sample_playback_rate (HSAMPLE S, S32 playback_rate)
{
    // fprintf(stderr, "%s: %08X, %d\n", __FUNCTION__, (int)S, playback_rate);
    S->playback_rate = playback_rate;
}

DXDEC void AILCALL AIL_set_sample_type (HSAMPLE S, S32 format, U32 flags)
{
    // fprintf(stderr, "%s: %08X %d %d\n", __FUNCTION__, (int)S, format, flags);
    if (flags)
        DebugBreak();
    S->stereo = format & 2;
    S->adpcm = format & 4;
}

DXDEC void AILCALL AIL_set_sample_user_data (HSAMPLE S, U32 index, S32 value)
{
    // fprintf(stderr, "%s, %d, %08X\n", __FUNCTION__, index, value);
    S->user[index] = value;
}

DXDEC void AILCALL AIL_set_sample_volume (HSAMPLE S, S32 volume)
{
    // fprintf(stderr, "%s: %08X, %d\n", __FUNCTION__, (int)S, volume);
    alSourcef(S->source, AL_GAIN, volume / 127.0f);
}

DXDEC void AILCALL AIL_set_stream_position(HSTREAM stream,S32 offset)
{
    SDL_LockMutex(stream->dig->mutex);
    stream->chunk_size = 0;
    stream->chunk_pos = 0;
    stream->buffered = 0;
    fseek(stream->file, 12, SEEK_SET);
    stream->seek(stream, offset);
    SDL_UnlockMutex(stream->dig->mutex);
}

DXDEC void AILCALL AIL_set_stream_volume(HSTREAM stream,S32 volume)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    alSourcef(stream->source, AL_GAIN, volume / 127.0f);
}

DXDEC void AILCALL AIL_set_timer_frequency (HTIMER timer, U32 hertz)
{
    // fprintf(stderr, "%s %d\n", __FUNCTION__, hertz);
    timer->interval = 1000.0 / hertz;
}

DXDEC void AILCALL AIL_shutdown (void)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    DebugBreak();
}

DXDEC void AILCALL AIL_start_stream(HSTREAM stream)
{
    stream->playing = 1;
}

static Uint32 timer_callback(Uint32 interval, void *param)
{
    HTIMER timer = param;
    
    timer->cb(timer->user);
    return timer->interval;
}

DXDEC void AILCALL AIL_start_timer (HTIMER timer)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    SDL_AddTimer(timer->interval, timer_callback, timer);
}

DXDEC S32 AILCALL AIL_startup (void)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    return 0;
}

DXDEC void AILCALL AIL_stop_sample (HSAMPLE S)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    DebugBreak();
}

DXDEC void AILCALL AIL_stop_timer (HTIMER timer)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    DebugBreak();
}

DXDEC S32 AILCALL AIL_stream_position(HSTREAM stream)
{
    unsigned int result;
    result = stream->tell(stream);
    return result;
}

DXDEC S32 AILCALL AIL_stream_status(HSTREAM stream)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
    return stream->playing ? 4 : 2;
}

DXDEC void AILCALL AIL_waveOutClose (HDIGDRIVER drvr)
{
    // fprintf(stderr, "%s\n", __FUNCTION__);
}

#if 0
// https://wiki.multimedia.cx/index.php/Microsoft_ADPCM
int AdaptationTable [] = { 
    230, 230, 230, 230, 307, 409, 512, 614, 
    768, 614, 512, 409, 307, 230, 230, 230 
};
int AdaptCoeff1 [] = { 256, 512, 0, 192, 240, 460, 392 };
int AdaptCoeff2 [] = { 0, -256, 0, 64, 0, -208, -232 };

static unsigned int decode_adpcm(signed short *out, const BYTE *data, unsigned int size)
{
    int8_t nibble;
    unsigned int i, samples = 0;
    int predictor;
    int16_t coeff1, coeff2, delta, sample1, sample2;

    coeff1 = AdaptCoeff1[data[0]];
    coeff2 = AdaptCoeff2[data[0]];
    delta = data[1] | (data[2] << 8);
    sample1 = data[3] | (data[4] << 8);
    sample2 = data[5] | (data[6] << 8);

    out[samples++] = sample2;
    out[samples++] = sample1;

    for (i = 7; i < size; i++)
    {
        nibble = (int8_t)data[i] >> 4;
        predictor = ((sample1 * coeff1) + (sample2 * coeff2)) / 256;
        predictor += nibble * delta;
        sample2 = sample1;
        sample1 = sat16(predictor);
        delta = sat16((AdaptationTable[nibble & 15] * delta) / 256);
        out[samples++] = sample1;

        nibble = (int8_t)(data[i] << 4) >> 4;
        predictor = ((sample1 * coeff1) + (sample2 * coeff2)) / 256;
        predictor += nibble * delta;
        sample2 = sample1;
        sample1 = sat16(predictor);
        delta = sat16((AdaptationTable[nibble & 15] * delta) / 256);
        out[samples++] = sample1;
    }

    return samples;
}

static unsigned int decode_adpcm_stereo(signed short *out, const BYTE *data, unsigned int size)
{
    int8_t nibble;
    unsigned int i, samples = 0;
    int lpredictor, rpredictor;
    int16_t lcoeff1, lcoeff2, ldelta, lsample1, lsample2;
    int16_t rcoeff1, rcoeff2, rdelta, rsample1, rsample2;

    lcoeff1 = AdaptCoeff1[data[0]];
    lcoeff2 = AdaptCoeff2[data[0]];
    rcoeff1 = AdaptCoeff1[data[1]];
    rcoeff2 = AdaptCoeff2[data[1]];
    ldelta = data[2] | (data[3] << 8);
    rdelta = data[4] | (data[5] << 8);
    lsample1 = data[6] | (data[7] << 8);
    rsample1 = data[8] | (data[9] << 8);
    lsample2 = data[10] | (data[11] << 8);
    rsample2 = data[12] | (data[13] << 8);

    out[samples++] = lsample2;
    out[samples++] = rsample2;
    out[samples++] = lsample1;
    out[samples++] = rsample1;

    for (i = 14; i < size; i++)
    {
        nibble = (int8_t)data[i] >> 4;
        lpredictor = ((lsample1 * lcoeff1) + (lsample2 * lcoeff2)) / 256;
        lpredictor += nibble * ldelta;
        lsample2 = lsample1;
        lsample1 = sat16(lpredictor);
        ldelta = sat16((AdaptationTable[nibble & 15] * ldelta) / 256);
        out[samples++] = lsample1;

        nibble = (int8_t)(data[i] << 4) >> 4;
        rpredictor = ((rsample1 * rcoeff1) + (rsample2 * rcoeff2)) / 256;
        rpredictor += nibble * rdelta;
        rsample2 = rsample1;
        rsample1 = sat16(rpredictor);
        rdelta = sat16((AdaptationTable[nibble & 15] * rdelta) / 256);
        out[samples++] = rsample1;
    }

    return samples;
}
#endif

static void sample_play_adpcm(HSAMPLE S, const BYTE *data, unsigned int size)
{
    signed short decoded[4096];
    unsigned int decoded_samples = 0;

    if (!S->adpcm)
        DebugBreak();

    if (S->stereo)
        decoded_samples = decode_adpcm_stereo(decoded, data, size);
    else
        decoded_samples = decode_adpcm(decoded, data, size);

    // cap to avoid overflowing decoded[]
    {
        unsigned int max_out = (unsigned int)(sizeof(decoded) / sizeof(decoded[0]));
        if (decoded_samples > max_out)
            decoded_samples = max_out;
    }

    S->hwready--;
#ifdef __EMSCRIPTEN__
    if (!S->stereo)
    {
        unsigned int i;
        for (i = decoded_samples; i > 0; i--)
            decoded[2 * i - 2] = decoded[2 * i - 1] = decoded[i - 1];
        decoded_samples *= 2;
    }
    alBufferData(S->hwbuf[S->hwready], AL_FORMAT_STEREO16, decoded, decoded_samples * 2, S->playback_rate);
#else
    alBufferData(S->hwbuf[S->hwready],
                 S->stereo ? AL_FORMAT_STEREO16 : AL_FORMAT_MONO16,
                 decoded, decoded_samples * 2, S->playback_rate);
#endif
    checkError();
    alSourceQueueBuffers(S->source, 1, &S->hwbuf[S->hwready]);
    checkError();
}

static void sample_work(HSAMPLE S)
{
    struct _SAMPLE_BUFFER *buf = &S->buffers[S->current];

    if (S->block_size == 0) {
        S->block_size = S->stereo ? 2048u : 1024u;
    }

    if (S->ready == 2)
    {
        sample_eos(S);
        return;
    }

    if (buf->length == 0)
    {
        sample_eob(S);
        sample_eos(S);
        return;
    }

    sample_unqueue_buffers(S);

    while (S->hwready)
    {
        ALint state;

        unsigned int remaining = buf->length - buf->position;
        if (remaining < S->block_size) {
            /* Don’t decode partial ADPCM blocks; treat as end of buffer. */
            buf->position = buf->length;

            sample_eob(S);
            buf = &S->buffers[S->current];
            if (buf->length == 0)
                sample_eos(S);
            break;
        }

        sample_play_adpcm(S, (BYTE *)buf->buffer + buf->position, S->block_size);
        buf->position += S->block_size;

        alGetSourcei(S->source, AL_SOURCE_STATE, &state);
        if (S->playing && state != AL_PLAYING)
            alSourcePlay(S->source);

        if (buf->position >= buf->length) {
            sample_eob(S);
            buf = &S->buffers[S->current];
            if (buf->length == 0) {
                sample_eos(S);
                break;
            }
        }
    }
}

static void stream_work(HSTREAM stream)
{
    static WORD buffer[16 * 1024];
    unsigned int channels = stream->stereo ? 2 : 1;
    // We need to queue 33ms of audio data.
    unsigned int min_samples = stream->playback_rate * channels / 30;

    stream_unqueue_buffers(stream);

    while (stream->hwready)
    {
        unsigned int offset = 0;
        ALint state;

        while (offset < min_samples)
        {
            unsigned int samples = stream->decode(stream, buffer + offset, min_samples * 2 - offset);
            if (samples == 0)
                break;
            offset += samples;
        }

        if (offset == 0)
            break;

        stream->hwready--;
        alBufferData(stream->hwbuf[stream->hwready], stream->stereo ? AL_FORMAT_STEREO16 : AL_FORMAT_MONO16, buffer, offset * 2, stream->playback_rate);
        checkError();
        alSourceQueueBuffers(stream->source, 1, &stream->hwbuf[stream->hwready]);
        checkError();

        alGetSourcei(stream->source, AL_SOURCE_STATE, &state);
        if (stream->playing && state != AL_PLAYING)
            alSourcePlay(stream->source);
    }
}

static Uint32 work_callback(Uint32 interval, void *param)
{
    HDIGDRIVER dig = param;
    HSAMPLE sample;
    HSTREAM stream;

    SDL_LockMutex(dig->mutex);

    for (sample = dig->sample_head; sample; sample = sample->next)
    {
        if (!sample->playing)
            continue;
        sample_work(sample);
    }

    for (stream = dig->stream_head; stream; stream = stream->next)
    {
        if (!stream->playing)
            continue;
        stream_work(stream);
    }

    SDL_UnlockMutex(dig->mutex);

    return interval;
}

DXDEC S32 AILCALL AIL_waveOutOpen (HDIGDRIVER FAR *pdrvr, LPHWAVEOUT FAR *lphWaveOut, S32 wDeviceID, LPWAVEFORMAT lpFormat)
{
    HDIGDRIVER dig = calloc(1, sizeof(*dig));
    // fprintf(stderr, "%s\n", __FUNCTION__);
    dig->device = alcOpenDevice(NULL);
    dprintf("AL device: %08x", (int)dig->device);
    if (!dig->device)
        checkError();
    dig->context = alcCreateContext(dig->device, NULL);
    dprintf("AL context: %08x", (int)dig->context);
    if (!dig->context)
        checkError();
    alcMakeContextCurrent(dig->context);
    checkError();
    dig->mutex = SDL_CreateMutex();
    SDL_AddTimer(1000.0 / 60, work_callback, dig);
    alListenerf(AL_GAIN, 1.0f);
    alListener3f(AL_POSITION, 0.0f, 0.0f, 0.0f);
    *pdrvr = dig;
    return 0;
}
