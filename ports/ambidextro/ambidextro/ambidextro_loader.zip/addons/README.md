# Godot Mod Loader (Fork)

This folder contains a fork of the following repository and commit:

[https://github.com/GodotModding/godot-mod-loader/tree/a165641b5a4644103beb59bc687cf8d0a10a51d7/addons](https://github.com/GodotModding/godot-mod-loader/tree/a165641b5a4644103beb59bc687cf8d0a10a51d7/addons)

All credit goes to the original authors.
