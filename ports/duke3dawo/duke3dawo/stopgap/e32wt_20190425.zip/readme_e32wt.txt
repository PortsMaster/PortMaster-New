Duke Nukem 3D: 20th Anniversary World Tour - Stopgap Compatibility Layer for EDuke32
by Hendricks266
Release 20190425

https://forums.duke4.net/topic/8966-/

TODO:
- Some breakable objects
- Incinerator
- Multiplayer Incinerator pickups are not removed
- New projectiles
- Invert green channel of normal maps via def token
- Episode 5 ending
- Classic mini-HUD armor box
- Status bar number positioning adjustments
- RTS new voice support
- General stability
