#include "pille.h"

Pille::Pille() {
}

Pille::~Pille() {
}
