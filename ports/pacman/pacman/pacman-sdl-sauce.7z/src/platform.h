#ifndef PLATFORM_H
#define PLATFORM_H
void getFilePath(char filePath[], const char file[]);
#endif