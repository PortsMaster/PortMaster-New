#ifndef PACMAN_H
#define PACMAN_H
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include "ghost_figur.h"
#include "pacman_figur.h"
#include "menu_main.h"


#endif

