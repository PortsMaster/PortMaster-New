/* This header must be included *only* from be_gamedefs.h */

#ifdef REFKEEN_HAS_VER_CATABYSS
#include "be_gamedefs_catabyss.h"
#endif
#ifdef REFKEEN_HAS_VER_CATARM
#include "be_gamedefs_catarm.h"
#endif
#ifdef REFKEEN_HAS_VER_CATAPOC
#include "be_gamedefs_catapoc.h"
#endif
