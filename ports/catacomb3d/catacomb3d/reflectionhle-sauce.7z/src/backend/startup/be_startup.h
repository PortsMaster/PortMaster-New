#ifndef BE_STARTUP_H
#define BE_STARTUP_H
#include "../gamedefs/be_gamedefs_structs.h"

extern unsigned char *g_be_current_exeImage;
extern const BE_EXEFileDetails_T *g_be_current_exeFileDetails;

#endif
