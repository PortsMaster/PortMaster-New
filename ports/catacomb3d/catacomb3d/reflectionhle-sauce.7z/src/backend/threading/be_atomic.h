#ifdef REFKEEN_CONFIG_THREADS
#include "be_atomic_sdl.h"
#endif
