int BEL_ST_PrepareMainThreadForAudio(int *freq, int *channels, int expectedCallbackBufferLen);
void BEL_ST_ClearMainThreadAudioResources(void);
void BE_ST_PrepareForManualAudioCallbackCall(void);
