#ifndef BE_FILESYSTEM_APP_PATHS_H
#define BE_FILESYSTEM_APP_PATHS_H

#include "be_filesystem_len_bounds.h"
#include "be_filesystem_tchar.h"

extern TCHAR g_be_appDataPath[BE_CROSS_PATH_LEN_BOUND];
extern TCHAR g_be_appNewCfgPath[BE_CROSS_PATH_LEN_BOUND];

#endif
