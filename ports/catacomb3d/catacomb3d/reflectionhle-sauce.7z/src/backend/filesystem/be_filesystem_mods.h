#ifndef BE_FILESYSTEM_MODS_H
#define BE_FILESYSTEM_MODS_H

#include "be_filesystem_tchar.h"

extern TCHAR g_be_modPath[];

void BE_Cross_SetModPath(const char *path);

#endif
