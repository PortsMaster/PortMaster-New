#include <stdbool.h>
#include <stdio.h>

bool Unlzexe_unpack(FILE *ifile, unsigned char *obuff, int buffsize);
