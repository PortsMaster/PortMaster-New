#define  QUITSUR  	"Estas seguro que quieres\n"\
					"parar este gran juego?"

#define  CURGAME  	"Ahora estas en\n"\
					"un juego. Si continuas\n"\
					"borras el juego viejo. O.K.?"

#define  GAMESVD  "Ya hay un juego\n"\
				  "guardado en esta posicion.\n"\
				  "sobre-escribir?"

#define  ENDGAMESTR  "Estas seguro que quieres\n"\
					 "terminar el juego que\n"\
					 "estas jugando?  (S  o  N):"

#define   STR_NG    "Juego nuevo"
#define   STR_SD    "Sonido"
#define   STR_CL    "Control"
#define   STR_LG    "Cargar juego"
#define   STR_SG    "Guardar juego"
#define   STR_CV    "Cambiar vista"
#define   STR_VS    "Ver anotacion"
#define  STR_EG     "Abandonar"
#define   STR_BD    "Regresar al demo"
#define  STR_QT     "Parar"

#define  STR_LOADING  "Cargando"
#define  STR_SAVING   "Guardando"

#define  STR_GAME  "Regresar, jugar"
#define  STR_DEMO  "Regresar al Demo"
#define  STR_LGC         "Cargar juego llamado\n\""
#define  STR_EMPTY       "vacio"
#define  STR_CALIB       "Calibrar"
#define  STR_JOYST       "Joystick"
#define  STR_MOVEJOY 	"Mover joystick a\n"\
						"arriba izq y\n"\
						"oprimir boton 0\n"
#define  STR_MOVEJOY2  	"Mover joystick a\n"\
						"abajo derecha y\n"\
						"oprimir boton 1\n"
#define  STR_ESCEXIT     "ESC para salir"
#define  STR_NONE  "Ninguno"
#define   STR_PC         "P.C. bocina"
#define   STR_ALSB       "AdLib/Sound Blaster"
#define   STR_DISNEY  "Disney Sound Source"
#define   STR_SB         "Sound Blaster"

#define   STR_MOUSEEN         "Raton activado"
#define   STR_JOYEN   "Joystick activado"
#define   STR_PORT2   "Use joystick puerto 2"
#define   STR_GAMEPAD         "Gravis Gamepad Activada"
#define   STR_SENS  "Raton Sensibilidad"
#define   STR_CUSTOM     "Modificar controles"
#define   STR_DADDY   "Papi puedo jugar?"
#define   STR_HURTME   "No me hieras."
#define   STR_BRINGEM    "�Echamelos!"
#define   STR_DEATH "La muerte encarnada"

#define   STR_MOUSEADJ  "Raton ajustar sensibilidad"
#define  STR_SLOW  "Lento"
#define  STR_FAST   "Rapido"

#define   STR_CRUN  "Corre"
#define  STR_COPEN       "Abre"
#define  STR_CFIRE        "Fuego"
#define  STR_CSTRAFE     "Ametrallar"

#define   STR_LEFT       "Izquierda"
#define   STR_RIGHT "Derecha"
#define   STR_FRWD  "Adelante"
#define   STR_BKWD  "Atras"
#define   STR_THINK "Pensando"

#define   STR_SIZE1 "Use flechas para ajustar"
#define   STR_SIZE2 "Enter para aceptar"
#define   STR_SIZE3 "Esc para cancelar"

#define   STR_YOUWIN     "Tu ganas"

#define   STR_TOTALTIME  "Tiempo total"

#define   STR_RATKILL       "Muertes    %"
#define   STR_RATSECRET  	"Secreto    %"
#define   STR_RATTREASURE   "Tesoros    %"

#define   STR_BONUS 	"Bono"
#define   STR_TIME      "Tiempo"
#define   STR_PAR       "Par"

#define   STR_RAT2KILL   	"Muertes    %" // ratio = promedio
#define   STR_RAT2SECRET   	"Secreto    %"
#define   STR_RAT2TREASURE  "Tesoros    %"

#define   STR_DEFEATED   "Derrotado!"

#define   STR_CHEATER1  "Ahora tienes 100% salud"
#define   STR_CHEATER2   "99 balas y dos llaves"
#define   STR_CHEATER3   "Notar que has basicamente"
#define   STR_CHEATER4   "eliminado tus chances de"
#define   STR_CHEATER5   "obtener puntos altos"

#define   STR_NOSPACE1   "No hay suficiente espacio"
#define   STR_NOSPACE2   "en tu disco para guardar juego"

#define   STR_SAVECHT1   "Tu archivo para guardar juego es"
#define   STR_SAVECHT2   "diremos,\"corrupto\"."
#define   STR_SAVECHT3   "Pero te dire, sigue y"
#define  STR_SAVECHT4   "de todos modos juega"

#define   STR_SEEAGAIN      "Veamos eso de nuevo"

