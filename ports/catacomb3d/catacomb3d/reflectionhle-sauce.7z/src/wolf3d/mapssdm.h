///////////////////////////////////////
//
// TED5 Map Header for SDM
//
///////////////////////////////////////

//
// Map Names
//
typedef enum {
		TUNNELS_1_MAP,           // 0
		TUNNELS_2_MAP,           // 1
		LASTMAP
	     } mapnames;
