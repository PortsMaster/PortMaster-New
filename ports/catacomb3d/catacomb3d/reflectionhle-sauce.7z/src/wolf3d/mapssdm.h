REFKEEN_NS_B

///////////////////////////////////////
//
// TED5 Map Header for SDM
//
///////////////////////////////////////

//
// Map Names
//
typedef enum {
		TUNNELS_1_MAP,           // 0
		TUNNELS_2_MAP,           // 1
		LASTMAP
	     } mapnames;

REFKEEN_NS_E
