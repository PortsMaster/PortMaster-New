## Notes

- Thanks [Kexuan Zhang](https://github.com/zzxzzk115)  for developing this game.
- Game keeps aspect, 4:3.

## Controls

| Button | Action |
|--|--| 
|A/B|Confirm or buy|
|Left/Right|Select item|
|Down|Grappling hook|
|Up|Dynamite|
|Select|Continue if goal is reached|
|Start|Confirm|


