# Release Notes

2022/6/2 v1.0.0-rc:

- Updated README.md

2022/5/30 v1.0.0-b.2:

- Added push.lua for high resolution situation.
- Fixed filter on GameShell.

2022/5/28 v1.0.0-b.1:

- Fixed [Issue #5](https://github.com/zzxzzk115/GoldMiner-GameShell/issues/5)
- Modified bigger explosive FX's size.
- Modified mole's animation speed.

2022/5/27 v1.0.0-b:

- Limited FPS to 60
- Fixed QuestionBag view error.
- Fixed [Issue #3](https://github.com/zzxzzk115/GoldMiner-GameShell/issues/3)

2022/5/26 1.0.0a:

- Added High Score System.
- Fixed [Issue #2](https://github.com/zzxzzk115/GoldMiner-GameShell/issues/2).
- Numerical balance adjustment.

2022/5/26 DEMO-4:

- Added new entities: Skulls,Bones,TNTs.
- Added new FX: Bigger explosive fx.
- Completed all of the levels.
- Fixed some bugs.

2022/5/24 DEMO-3:

- Added FXs.
- Added Strength! effect.
- Added miner animation.
- Fixed [Issue #1](https://github.com/zzxzzk115/GoldMiner-GameShell/issues/1).
- Numerical balance adjustment.

2022/5/23 DEMO-2: 

- Added new map entity: Diamond.
- Added new systems: Shop system, Props system.
- Added new levels: level-2 and level-3.
- Fixed some bugs.