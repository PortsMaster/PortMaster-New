======================
HOW TO BUILD MICEAMAZE
======================

You need:
- GCC C++ compiler and GNU Make
- OpenGL
- SDL2
- SDL2_mixer
- SDL2_ttf
- DejaVu font installed
- rsvg (sudo apt install librsvg2-bin)


Without installing:
make
./miceamaze

With installation (requires root privileges):
make
sudo make install
miceamaze

