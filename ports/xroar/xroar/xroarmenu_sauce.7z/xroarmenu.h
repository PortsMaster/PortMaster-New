#ifndef XROARMENU_H
#define XROARMENU_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>

#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdbool.h>

TTF_Font *font = NULL;

SDL_Texture *textTexture = NULL;
SDL_Texture *highlightTexture = NULL;

static int screenw = 480;
static int screenh = 320;

// VAR_INC and VAR_DEC courtesy of @kloptops
#define VAR_INC(variable, amount, total) \
    variable = (variable + amount) % total
#define VAR_DEC(variable, amount, total) \
    variable = (variable - amount + total) % total

// min & max clamp for pageup/pagedown courtesy of @kloptops
#define max(a, b) \
    ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
        _a > _b ? _a : _b; })
#define min(a, b) \
    ({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
        _a < _b ? _a : _b; })

#define MAX_ROMS 900
#define DISPLAY_HEIGHT 14
#define SCROLL_SIZE 8

char **files = NULL;
char **ROMs = NULL;

int numxroarBins = 0;
int numROMs = 0;

const char *xroarExecutable = "xroar";

//const char *xroarBins[0];

/* 
Use of strcasecmp and strcasestr enabled requiring only one entry per name
instead of several to accomodate case sensitivity - courtesy of @kloptops
*/

typedef struct {
    const char *label;  // Human-readable name
    const char *value;  // Actual -machine argument
} MachineOption;

const MachineOption machineOptions[] = {
    {"Dragon 32", "dragon32"},
    {"Dragon 64", "dragon64"},
    {"Tano Dragon (NTSC)", "tano"},
    {"Dragon Professional (Alpha)", "dragonpro"},
    {"Dragon 200-E", "dragon200e"},
    {"Tandy CoCo (PAL)", "coco"},
    {"Tandy CoCo (NTSC)", "cocous"},
    {"Tandy CoCo 2B (PAL, T1)", "coco2b"},
    {"Tandy CoCo 2B (NTSC, T1)", "coco2bus"},
    {"Tandy Deluxe CoCo", "deluxecoco"},
    {"Tandy CoCo 3", "coco3"},
    {"Tandy CoCo 3 (6309)", "coco3h"},
    {"Tandy CoCo 3 (PAL)", "coco3p"},
    {"Tandy CoCo 3 (PAL, 6309)", "coco3ph"},
    {"Dynacom MX-1600", "mx1600"},
    {"Tandy MC-10", "mc10"},
    {"Matra & Hachette Alice", "alice"}
};

const int numMachineOptions = sizeof(machineOptions) / sizeof(machineOptions[0]);

const char *xroarExtensions[] = {
    ".dmk", ".jvc", ".dsk", ".vdk", ".bin", ".sna", ".hex", ".cas", ".rom", ".ccc", ".wav"
};

#endif // XROARMENU_H
