#include "xroarmenu.h"

bool quit = false;

// Function to handle SDL2 events
int handleEvents() {
    SDL_Event event;
    while (SDL_PollEvent(&event) != 0) {
        if (event.type == SDL_QUIT) {
            quit = true;
            return 1;
        } else if (event.type == SDL_KEYDOWN) {
            switch (event.key.keysym.sym) {
            //    case SDLK_UP:           return SDLK_UP;
            //    case SDLK_DOWN:         return SDLK_DOWN;
            //    case SDLK_LEFT:         return SDLK_LEFT;
            //    case SDLK_RIGHT:        return SDLK_RIGHT;
                case SDLK_PAGEUP:       return SDLK_PAGEUP;
                case SDLK_PAGEDOWN:     return SDLK_PAGEDOWN;
            //    case SDLK_RETURN:       return SDLK_RETURN;
            //    case SDLK_SPACE:        return SDLK_SPACE;
                case SDLK_LCTRL:        return SDLK_LCTRL;
                case SDLK_ESCAPE:       return SDLK_ESCAPE;
                case SDLK_LEFTBRACKET:  return SDLK_LEFTBRACKET;
                case SDLK_RIGHTBRACKET: return SDLK_RIGHTBRACKET;
            }
        } else if (event.type == SDL_CONTROLLERBUTTONDOWN) {
            switch (event.cbutton.button) {
                case SDL_CONTROLLER_BUTTON_DPAD_UP:    return SDL_CONTROLLER_BUTTON_DPAD_UP;
                case SDL_CONTROLLER_BUTTON_DPAD_DOWN:  return SDL_CONTROLLER_BUTTON_DPAD_DOWN;
                case SDL_CONTROLLER_BUTTON_DPAD_LEFT:  return SDL_CONTROLLER_BUTTON_DPAD_LEFT;
                case SDL_CONTROLLER_BUTTON_DPAD_RIGHT: return SDL_CONTROLLER_BUTTON_DPAD_RIGHT;
                case SDL_CONTROLLER_BUTTON_BACK:       return SDL_CONTROLLER_BUTTON_BACK;
                case SDL_CONTROLLER_BUTTON_A:
                case SDL_CONTROLLER_BUTTON_B:
                case SDL_CONTROLLER_BUTTON_START:      return SDL_CONTROLLER_BUTTON_START;
            }
        }
    }
    return 0;
}

// Function to check if a file exists
int fileExists(const char *filename) {
    return access(filename, F_OK) != -1;
}

void setup_and_launch_gptokeyb(const char *romPath, const char *gameDir, const char *deviceArch) {
    const char *gptoKeyb = getenv("GPTOKEYB");
    if (!gptoKeyb) {
        printf("GPTOKEYB not set.");
    }

    const char *romFilename = strrchr(romPath, '/');
    romFilename = romFilename ? romFilename + 1 : romPath;

    if (!*romFilename) {
        fprintf(stderr, "Warning: ROM filename is empty, skipping GPTK creation.\n");
        return;
    }

    char romNameNoExt[256];
    strncpy(romNameNoExt, romFilename, sizeof(romNameNoExt));
    char *dot = strrchr(romNameNoExt, '.');
    if (dot) *dot = '\0';  // remove extension

    // Build expected gptk path
    char gptkPath[512];
    snprintf(gptkPath, sizeof(gptkPath), "%s/gptk/%s.gptk", gameDir, romNameNoExt);

    // Check if file exists
    if (access(gptkPath, F_OK) == -1) {
        // File does not exist, copy default
        char defaultGptk[512];
        snprintf(defaultGptk, sizeof(defaultGptk), "%s/gptk/xroar.gptk", gameDir);
        printf("Creating missing gptk config: %s\n", gptkPath);
        FILE *src = fopen(defaultGptk, "rb");
        FILE *dst = fopen(gptkPath, "wb");
        if (src && dst) {
            char buf[1024];
            size_t n;
            while ((n = fread(buf, 1, sizeof(buf), src)) > 0)
                fwrite(buf, 1, n, dst);
        }
        if (src) fclose(src);
        if (dst) fclose(dst);
    }

    // Kill any running gptokeyb
    system("killall -9 gptokeyb");

    // Launch gptokeyb
    char gptkCommand[1024];
    snprintf(gptkCommand, sizeof(gptkCommand),
        "%s xroar.%s -c \"%s\" &",
        gptoKeyb,
        deviceArch,
        gptkPath
    );
    system(gptkCommand);
}

// Function to search for executables in the specified directory
void searchExecutables(const char *directory, const char *executableName) {
    DIR *dir;
    struct dirent *ent;

    if ((dir = opendir(directory)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            if (strcasecmp(ent->d_name, executableName) == 0) {
                // Found the executable
                char *path = malloc(strlen(directory) + strlen(executableName) + 2);
                sprintf(path, "%s/%s", directory, executableName);
                files = realloc(files, (numxroarBins + 1) * sizeof(char *));
                files[numxroarBins++] = path;
            }
        }
        closedir(dir);
    }
}

// Function to detect and store paths of executable(s)
void detectExecutables() {

    const char *deviceArch = getenv("DEVICE_ARCH");
    if (!deviceArch) {
        printf("DEVICE_ARCH not set. Defaulting to: aarch64\n");
        deviceArch = "aarch64";
    } else {
        printf("DEVICE_ARCH=%s\n", deviceArch);
    }

    static char xroarExecutableWithArch[256];
    snprintf(xroarExecutableWithArch, sizeof(xroarExecutableWithArch), "%s.%s", xroarExecutable, deviceArch);
    searchExecutables(".", xroarExecutableWithArch);
}

// Function to detect if any valid ROMs are present
void detectROMs(const char *directory) {
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir(directory)) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            char path[1024];
            snprintf(path, sizeof(path), "%s/%s", directory, ent->d_name);

            // Use stat to check if it's a directory
            struct stat statbuf;
            if (stat(path, &statbuf) != 0) {
                continue;
            }

            if (S_ISDIR(statbuf.st_mode) && strcasecmp(ent->d_name, ".") != 0 && strcasecmp(ent->d_name, "..") != 0) {
                // Recursive call to search in subdirectory
                detectROMs(path);
            } else {
                for (size_t i = 0; i < sizeof(xroarExtensions) / sizeof(xroarExtensions[0]); ++i) {
                    if (strcasestr(ent->d_name, xroarExtensions[i])) {
                            // Trimming leading "./" from the path
                            if (strncmp(path, "./", 2) == 0) {
                                memmove(path, path + 2, strlen(path) - 1);
                            }

                            // Save the ROM path (dynamically)
                            ROMs = realloc(ROMs, (numROMs + 1) * sizeof(char *));
                            ROMs[numROMs++] = strdup(path);
                            break;
                    }
                }
            }
        }
        closedir(dir);
    }
}

// Function to free allocated memory
void freeMemory() {
    for (int i = 0; i < numxroarBins; i++) {
        free(files[i]);
    }
    free(files);
}

void renderText(SDL_Renderer *renderer, TTF_Font *font, const char *text, int x, int y, int r, int g, int b) {
    SDL_Color textColor = {r, g, b, 255};
    SDL_Surface *textSurface = TTF_RenderText_Solid(font, text, textColor);

    if (textSurface) {
        textTexture = SDL_CreateTextureFromSurface(renderer, textSurface);
        SDL_FreeSurface(textSurface);

        SDL_Rect dstRect = {x, y, textSurface->w, textSurface->h};
        SDL_RenderCopy(renderer, textTexture, NULL, &dstRect);
        SDL_DestroyTexture(textTexture);
    }
}

// Function to display a menu with existing files
void displayMenu(SDL_Renderer *renderer, const char **options, int numOptions, int selected, const char *title, int start) {
    // Clear the screen
    SDL_SetRenderDrawColor(renderer, 56, 56, 56, 255); // Gray
    SDL_RenderClear(renderer);

    // Render title
    renderText(renderer, font, title, 10, 10, 224, 210, 112); // Yellow

    int displayStart = (selected >= DISPLAY_HEIGHT) ? selected - DISPLAY_HEIGHT + 1 : 0;
    int displayEnd = displayStart + DISPLAY_HEIGHT;

    // Adjust the display end index to prevent going beyond the array bounds
    displayEnd = (displayEnd > numOptions) ? numOptions : displayEnd;

    // Render options
        for (int i = displayStart; i < displayEnd; i++) {
            if (i == selected) {
            // Highlight the selected option
            SDL_SetRenderDrawColor(renderer, 0, 0, 128, 255); // Dark Blue
            SDL_Rect rect = {5, 27 + (i - displayStart) * 20, screenw - 10, 20};
            SDL_RenderFillRect(renderer, &rect);
        }
        renderText(renderer, font, options[i], 20, 30 + (i - displayStart) * 20, 224, 8, 8); // Dark Red
    }
    SDL_RenderPresent(renderer);
}

// Function to compare strings for qsort
int compareStrings(const void *a, const void *b) {
    return strcasecmp(*(const char **)a, *(const char **)b);
}

// Function to run the command
void runCommand(const char *command) {

    //system("pkill -f gptokeyb");
    //system("sudo kill -9 $(pidof gptokeyb)");
    //system("kill -9 $(pidof gptokeyb)");
    //system("killall -9 gptokeyb");

    pid_t pid = fork();

    if (pid == -1) {
        perror("fork");
        SDL_Quit();
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child process
        if (execlp("sh", "sh", "-c", command, NULL) == -1) {
            perror("execlp");
            SDL_Quit();
            exit(EXIT_FAILURE);
        }
    } else {
        // Parent process
        //SDL_Quit();
        //exit(0);
        int status;
        if (waitpid(pid, &status, 0) == -1) {
            perror("waitpid");
        }
    }
}

// The main program loop
int main() {

    // Initialize SDL2
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER) < 0) {
        fprintf(stderr, "SDL2 initialization failed: %s\n", SDL_GetError());
        return 1;
    }

    // Initialize game controller
    SDL_GameController *controller = NULL;
    if (SDL_NumJoysticks() > 0 && SDL_IsGameController(0)) {
        controller = SDL_GameControllerOpen(0);
        if (controller) {
            printf("Game controller connected: %s\n", SDL_GameControllerName(controller));
        } else {
            printf("Failed to open game controller.\n");
        }
    }

    // Initialize SDL2_ttf for text rendering
    if (TTF_Init() < 0) {
        fprintf(stderr, "SDL2_ttf initialization failed: %s\n", TTF_GetError());
        SDL_Quit();
        return 1;
    }

    // Create a window and renderer
    SDL_Window *window = SDL_CreateWindow("XRoar ROM Selection", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, screenw, screenh, SDL_WINDOW_SHOWN);
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    SDL_RenderSetLogicalSize(renderer, screenw, screenh);
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");

    //Load font
    font = TTF_OpenFont("fonts/Mini Sans 2X.ttf", 18);
    if (!font) {
        fprintf(stderr, "Error loading font: %s\n", TTF_GetError());
        return 1;
    }

    const char *gameDir = getenv("GAMEDIR");
    if (!gameDir) {
        printf("GAMEDIR not set. Defaulting to: .\n");
        gameDir = ".";
    } else {
        printf("GAMEDIR=%s\n", gameDir);
    }

    const char *deviceName = getenv("DEVICE_NAME");
    if (!deviceName) {
        printf("DEVICE_NAME not set. \n");
        deviceName = "Unknown";
    } else {
        printf("DEVICE_NAME=%s\n", deviceName);
    }

    const char *deviceArch = getenv("DEVICE_ARCH");
    if (!deviceArch) {
        printf("DEVICE_ARCH not set. Defaulting to: aarch64\n");
        deviceArch = "aarch64";
    } else {
        printf("DEVICE_ARCH=%s\n", deviceArch);
    }

    detectExecutables();

    if (numxroarBins == 0) {
        printf("Error: No xroar executables found.\n");
        return 1;
    }

    // Sort the detected executables
    qsort(files, numxroarBins, sizeof(char *), compareStrings);

//    int xroarbinSelected = 0;
    int romSelected = 0;
    int machineSelected = 0;

    // Build machine labels for menu display
    const char *machineLabels[numMachineOptions];
    for (int i = 0; i < numMachineOptions; ++i) {
        machineLabels[i] = machineOptions[i].label;
    }

// Emulator selection loop
//bool in_loop = true;
//while(in_loop) { 
//    int key;

//    while (1) {
//        key = handleEvents();
//        if (key == 0) {
            // No more events
//            break;
//        }

//        if (key == SDL_CONTROLLER_BUTTON_START || key == SDL_CONTROLLER_BUTTON_A || key == SDL_CONTROLLER_BUTTON_B) {
//            in_loop = false;
//            break; // Exit loop on Enter key
//        }

//        switch (key) {
//            case SDL_CONTROLLER_BUTTON_DPAD_UP:
//                VAR_DEC(xroarbinSelected, 1, numxroarBins);
//                break;
//            case SDL_CONTROLLER_BUTTON_DPAD_DOWN:
//                VAR_INC(xroarbinSelected, 1, numxroarBins);
//                break;
//            case SDLK_ESCAPE:
//            case SDL_CONTROLLER_BUTTON_BACK:
//                SDL_Quit();
//                exit(0);
//                break;
//        }
//    }
//    displayMenu(renderer, (const char **)files, numxroarBins, xroarbinSelected, "XRoar Emulator:", 0);
//    SDL_Delay(35);
//}


    //detectROMs(".");
    detectROMs("cartridges");
    detectROMs("carts");
    detectROMs("cassettes");
    detectROMs("gamedata");
    detectROMs("games");
    detectROMs("roms");
    detectROMs("tapes");
    detectROMs("dragon32");
    detectROMs("dragon64");
    detectROMs("tano");
    detectROMs("dragonpro");
    detectROMs("dragon200e");
    detectROMs("coco");
    detectROMs("cocous");
    detectROMs("coco2b");
    detectROMs("coco2bus");
    detectROMs("deluxecoco");
    detectROMs("coco3");
    detectROMs("coco3h");
    detectROMs("coco3p");
    detectROMs("coco3ph");
    detectROMs("mx1600");
    detectROMs("mc10");
    detectROMs("alice");

    // Sort the valid ROMs
    qsort(ROMs, numROMs, sizeof(char *), compareStrings);

bool in_loop = true;
while(in_loop) { 
    int key;

    while (1) {
        key = handleEvents();
        if (key == 0) {
            // No more events
            break;
        }

        if (key == SDL_CONTROLLER_BUTTON_START || key == SDL_CONTROLLER_BUTTON_A || key == SDL_CONTROLLER_BUTTON_B) {
            in_loop = false;
            break; // Exit loop on Enter key
        }

        switch (key) {
            case SDL_CONTROLLER_BUTTON_DPAD_UP:
                VAR_DEC(romSelected, 1, numROMs);
                break;
            case SDL_CONTROLLER_BUTTON_DPAD_DOWN:
                VAR_INC(romSelected, 1, numROMs);
                break;
            case SDLK_PAGEUP:
            case SDLK_LEFTBRACKET:
            case SDL_CONTROLLER_BUTTON_DPAD_LEFT:
                    romSelected = max(0, romSelected - SCROLL_SIZE);
                break;
            case SDLK_PAGEDOWN:
            case SDLK_RIGHTBRACKET:
            case SDL_CONTROLLER_BUTTON_DPAD_RIGHT:
                    romSelected = min(numROMs - 1, romSelected + SCROLL_SIZE);
                break;
            case SDLK_ESCAPE:
            case SDL_CONTROLLER_BUTTON_BACK:
                SDL_Quit();
                exit(0);
                break;
        }
    }
    displayMenu(renderer, (const char **)ROMs, numROMs, romSelected, "Choose ROM:", 0);
    SDL_Delay(35);
}

// Machine selection loop
in_loop = true;
while (in_loop) {
    int key;
    while (1) {
        key = handleEvents();
        if (key == 0) {
            break;
        }

        if (key == SDL_CONTROLLER_BUTTON_START || key == SDL_CONTROLLER_BUTTON_A || key == SDL_CONTROLLER_BUTTON_B) {
            in_loop = false;
            break; // Exit loop on Enter key
        }

        switch (key) {
            case SDL_CONTROLLER_BUTTON_DPAD_UP:
                VAR_DEC(machineSelected, 1, numMachineOptions);
                break;
            case SDL_CONTROLLER_BUTTON_DPAD_DOWN:
                VAR_INC(machineSelected, 1, numMachineOptions);
                break;
            case SDLK_PAGEUP:
            case SDLK_LEFTBRACKET:
            case SDL_CONTROLLER_BUTTON_DPAD_LEFT:
                    machineSelected = max(0, machineSelected - SCROLL_SIZE);
                break;
            case SDLK_PAGEDOWN:
            case SDLK_RIGHTBRACKET:
            case SDL_CONTROLLER_BUTTON_DPAD_RIGHT:
                    machineSelected = min(numMachineOptions - 1, machineSelected + SCROLL_SIZE);
                break;
            case SDLK_ESCAPE:
            case SDL_CONTROLLER_BUTTON_BACK:
                SDL_Quit();
                exit(0);
                break;
        }
    }
    displayMenu(renderer, machineLabels, numMachineOptions, machineSelected, "Select Emulated Machine:", 0);
    SDL_Delay(35);
}

// Display the command based on the selected emulator location
//if (xroarbinSelected < numxroarBins) {
//    printf("%s ", files[xroarbinSelected]);
if (numxroarBins > 0) {
    printf("%s ", files[0]);

    // Additional parameters for XRoar
        if (strcasestr(files[0], xroarExecutable) != NULL) {
            printf("-c %s/xroar.conf ", gameDir);
        }

        // Selected machine
            printf("-machine %s ", machineOptions[machineSelected].value);

        // Add correct -joy options based on DEVICE_NAME
        if (strcasestr(deviceName, "RG351P") || strcasestr(deviceName, "RG351M") || strcasestr(deviceName, "RG351V")) {
            printf(" -joy joy0 -joy-axis X=physical:0,-0 -joy-axis Y=physical:0,-1 ");
        } else if (strcasestr(deviceName, "GameForce") || strcasestr(deviceName, "CHI")) {
            printf(" -joy joy0 -joy-axis X=physical:1 -joy-axis Y=physical:0 ");
        } else {
            printf(" -joy-left joy0 ");
        }

        // Display selected ROM
        if (romSelected < numROMs) {
            printf(" %s ", ROMs[romSelected]);
        }

    printf("\n");
}

// Run the command
setup_and_launch_gptokeyb(ROMs[romSelected], gameDir, deviceArch);
usleep(300000);  // 300ms pause to give gptokeyb time to start

//if (xroarbinSelected < numxroarBins) {
//    char command[4096]; // Adjust the size based on your needs
if (numxroarBins > 0) {
    char command[4096]; // Adjust the size based on your needs

    // Append the xroar executable
        snprintf(command, sizeof(command), "%s", files[0] );

    // Additional parameters for XRoar
        if (strcasestr(files[0], xroarExecutable) != NULL) {
            snprintf(command + strlen(command), sizeof(command) - strlen(command), " -c %s/xroar.conf ", gameDir);
        }

    // Add correct -joy options based on DEVICE_NAME
        if (strcasestr(deviceName, "RG351P") || strcasestr(deviceName, "RG351M") || strcasestr(deviceName, "RG351V")) {
            snprintf(command + strlen(command), sizeof(command) - strlen(command), " -joy joy0 -joy-axis X=physical:0,-0 -joy-axis Y=physical:0,-1 ");
        } else if (strcasestr(deviceName, "GameForce") || strcasestr(deviceName, "CHI")) {
            snprintf(command + strlen(command), sizeof(command) - strlen(command), " -joy joy0 -joy-axis X=physical:1 -joy-axis Y=physical:0 ");
        } else {
            snprintf(command + strlen(command), sizeof(command) - strlen(command), " -joy-left joy0 ");
        }

    // Add selected machine
            snprintf(command + strlen(command), sizeof(command) - strlen(command), " -machine %s ", machineOptions[machineSelected].value);
        
    // Selected ROM
        if (romSelected < numROMs) {
            snprintf(command + strlen(command), sizeof(command) - strlen(command), " \"%s\"", ROMs[romSelected]);
        }

    // printf("%s\n", command);  // Optional: Print the command

    // Run the command
        runCommand(command);

    // Cleanup and exit the program
        freeMemory(); // Free allocated memory
        TTF_CloseFont(font);
        TTF_Quit();
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        SDL_Quit();
        exit(0);
}

freeMemory(); // Free allocated memory

return 0;
}
