-- Core 2048 Game Logic
-- Ported from MainGame.java

local Grid = require("grid")
local Tile = require("tile")
local save = require("save")
local sound = require("sound")

local Game = {}
Game.__index = Game

-- Game states
Game.STATE_PLAYING  = 0
Game.STATE_WON      = 1
Game.STATE_LOST     = 2
Game.STATE_ENDLESS  = 3   -- Continuing after winning
Game.STATE_PAUSED   = 4 -- Confirming accidental restart
Game.STATE_TARGETING_BOMB = 5
Game.STATE_TARGETING_SWAP_1 = 6
Game.STATE_TARGETING_SWAP_2 = 7
Game.STATE_TARGETING_SHIELD = 8

-- Direction constants: 0=up, 1=right, 2=down, 3=left
Game.DIR_UP    = 0
Game.DIR_RIGHT = 1
Game.DIR_DOWN  = 2
Game.DIR_LEFT  = 3

-- Direction vectors
local vectors = {
    [0] = {x =  0, y = -1},  -- up
    [1] = {x =  1, y =  0},  -- right
    [2] = {x =  0, y =  1},  -- down
    [3] = {x = -1, y =  0},  -- left
}

function Game.new(mode)
    local self = setmetatable({}, Game)
    self.mode = mode or "classic"
    _G.game = self
    save.saveLastMode(self.mode)
    self.rng = love.math.newRandomGenerator(math.floor(love.timer.getTime() * 1000) + love.math.random(1, 100000))
    self.size = 4
    self.targetValue = 2048
    if self.mode == "huge" then
        self.size = 5
        self.targetValue = 2048
    end
    self.grid = Grid.new(self.size, self.size)
    self.score = 0
    self.highScore = save.loadHighScore(self.mode)
    self.state = Game.STATE_PLAYING
    self.won = false
    self.moved = false

    -- Time Attack state
    self.timeLeft = nil
    self.totalTime = nil
    self.timeAttackBonus = 0  -- accumulated bonus time for this move
    self.timePopups = {}
    self.timerFlashTimer = 0
    self.timerPopTimer = 0
    self.lastCountdownSecond = nil
    self.second_chance_count = (_G.stats and _G.stats.second_chance_count) or 0

    -- Plus Mode state
    local initial_powerups = _G.cheat_max_powerups and 99 or 0
    local extra_undo, extra_bomb, extra_swap = 0, 0, 0
    if self.mode == "plus" and _G.stats then
        local pi = _G.stats.purchased_items or {}
        extra_undo = (pi["extra_undo"] or 0) + (_G.stats.powerup_undo_count or 0)
        extra_bomb = (pi["extra_bomb"] or 0) + (_G.stats.powerup_bomb_count or 0)
        extra_swap = (pi["extra_swap"] or 0) + (_G.stats.powerup_swap_count or 0)
    end
    self.powerups = { undo = initial_powerups + extra_undo, bomb = initial_powerups + extra_bomb, swap = initial_powerups + extra_swap }
    self.milestonesReached = {}
    self.floatingNotifications = {}
    self.cursorX = 1
    self.cursorY = 1
    self.swapTarget = nil

    self.bombAnimation = nil
    self.swapAnimation = nil

    -- Undo state
    self.undoHistory = {}
    self.canUndo = false

    -- Animation tracking
    self.animationTimer = 0
    self.animationDuration = 0.12  -- seconds
    if _G.animation_speed == "fast" then
        self.animationDuration = 0.06
    elseif _G.animation_speed == "instant" then
        self.animationDuration = 0
    elseif _G.animation_speed == "slow" then
        self.animationDuration = 0.24
    end

    self.max_score_for_coins = 0

    if sound and sound.startFreshGameBgm then
        sound.startFreshGameBgm()
    end

    -- Try to load saved game state
    local savedState = save.loadState(self.mode)
    local has_debug_layout = _G.cheat_debug_layout and _G.cheat_debug_layout ~= "None"
    if savedState and savedState.gridState and not has_debug_layout then
        if savedState.rngState and self.rng then
            self.rng:setState(savedState.rngState)
        end
        self.score = savedState.score or 0
        self.max_score_for_coins = savedState.max_score_for_coins or self.score
        self.state = savedState.state or Game.STATE_PLAYING
        self.prevShieldState = savedState.prevShieldState
        self.cursorX = savedState.cursorX
        self.cursorY = savedState.cursorY
        self.swapTarget = savedState.swapTarget
        self.shield_mode = savedState.shield_mode
        self.shield_index = savedState.shield_index
        self.won = savedState.won or false
        self.canUndo = savedState.canUndo or false
        self.grid:restoreState(savedState.gridState)
        if savedState.undoHistory then
            self.undoHistory = savedState.undoHistory
        else
            self.undoHistory = {}
            if savedState.undoState then
                table.insert(self.undoHistory, {
                    gridState = savedState.undoState,
                    score = savedState.undoScore or 0,
                    rng = savedState.undoRNG
                })
            end
        end

        if savedState.powerups then
            self.powerups = savedState.powerups
        end
        if savedState.milestonesReached then
            self.milestonesReached = savedState.milestonesReached
        end

        -- Restore Time Attack state
        if self.mode == "timeattack" then
            self.timeLeft = savedState.timeLeft or 60.0
            self.totalTime = savedState.totalTime or 60.0
            if savedState.timesUp ~= nil then
                self.timesUp = savedState.timesUp
            else
                self.timesUp = (self.timeLeft <= 0)
            end
        end

        if self.mode == "timeattack" and (self.timesUp or (self.timeLeft and self.timeLeft <= 0)) then
            self.state = Game.STATE_LOST
            self.timesUp = true
        elseif self.state == Game.STATE_PAUSED then
            self.state = self.won and Game.STATE_ENDLESS or (self:movesAvailable() and Game.STATE_PLAYING or Game.STATE_LOST)
        elseif self.state == Game.STATE_TARGETING_BOMB then
            if (self.powerups and self.powerups.bomb or 0) <= 0 then
                self.state = self.won and Game.STATE_ENDLESS or (self:movesAvailable() and Game.STATE_PLAYING or Game.STATE_LOST)
            else
                self.cursorX = math.max(1, math.min(self.size, self.cursorX or 2))
                self.cursorY = math.max(1, math.min(self.size, self.cursorY or 2))
            end
        elseif self.state == Game.STATE_TARGETING_SWAP_1 then
            if (self.powerups and self.powerups.swap or 0) <= 0 then
                self.state = self.won and Game.STATE_ENDLESS or (self:movesAvailable() and Game.STATE_PLAYING or Game.STATE_LOST)
            else
                self.cursorX = math.max(1, math.min(self.size, self.cursorX or 2))
                self.cursorY = math.max(1, math.min(self.size, self.cursorY or 2))
            end
        elseif self.state == Game.STATE_TARGETING_SWAP_2 then
            if (self.powerups and self.powerups.swap or 0) <= 0 then
                self.swapTarget = nil
                self.state = self.won and Game.STATE_ENDLESS or (self:movesAvailable() and Game.STATE_PLAYING or Game.STATE_LOST)
            else
                self.cursorX = math.max(1, math.min(self.size, self.cursorX or 2))
                self.cursorY = math.max(1, math.min(self.size, self.cursorY or 2))
                if not self.swapTarget or not self.swapTarget.x or not self.swapTarget.y then
                    self.swapTarget = nil
                    self.state = Game.STATE_TARGETING_SWAP_1
                end
            end
        elseif self.state == Game.STATE_TARGETING_SHIELD then
            if (self.second_chance_count or 0) <= 0 then
                self.state = self.prevShieldState or (self.won and Game.STATE_ENDLESS or (self:movesAvailable() and Game.STATE_PLAYING or Game.STATE_LOST))
            else
                if self.shield_mode ~= "row" and self.shield_mode ~= "col" then
                    self.shield_mode = "row"
                end
                self.shield_index = math.max(1, math.min(self.size, self.shield_index or 1))
            end
        elseif self.state == Game.STATE_PLAYING and not self.won and not self:movesAvailable() then
            self.state = Game.STATE_LOST
        end

        local saved_undo = savedState.undo_used_this_run
        if type(saved_undo) == "boolean" then
            self.undo_used_this_run = saved_undo and 1 or 0
        else
            self.undo_used_this_run = saved_undo or 0
        end

        local saved_swap = savedState.swap_used_this_run
        if type(saved_swap) == "boolean" then
            self.swap_used_this_run = saved_swap and 1 or 0
        else
            self.swap_used_this_run = saved_swap or 0
        end

        self.coin_rush_active = savedState.coin_rush_active or false
        self.second_chance_count = savedState.second_chance_count or 0
        self.start_booster_val = savedState.start_booster_val
        self.used_booster_this_run = savedState.used_booster_this_run or ((savedState.start_booster_val or 0) > 0) or false
        self.runTime = savedState.runTime or 0
        self.powerups_used_this_run = savedState.powerups_used_this_run or 0
        if _G.achievements then
            _G.achievements.powerups_used_this_run = self.powerups_used_this_run
        end
    else
        -- Start a fresh game if no save state exists
        self.powerups_used_this_run = 0
        if _G.achievements then
            _G.achievements.powerups_used_this_run = 0
            save.saveAchievements(_G.achievements)
        end

        self.used_booster_this_run = false
        self.runTime = 0
        self.undo_used_this_run = 0
        self.swap_used_this_run = 0

        self:addStartTiles()

        if _G.stats then
            _G.stats.games_played = (_G.stats.games_played or 0) + 1
            if self.mode == "classic" then
                _G.stats.classic_games = (_G.stats.classic_games or 0) + 1
            elseif self.mode == "plus" then
                _G.stats.plus_games = (_G.stats.plus_games or 0) + 1
            elseif self.mode == "timeattack" then
                _G.stats.timeattack_games = (_G.stats.timeattack_games or 0) + 1
                _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
            elseif self.mode == "huge" then
                _G.stats.huge_games = (_G.stats.huge_games or 0) + 1
                _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
            elseif self.mode == "nomercy" then
                _G.stats.nomercy_games = (_G.stats.nomercy_games or 0) + 1
                _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
            elseif self.mode == "goose" then
                _G.stats.goose_games = (_G.stats.goose_games or 0) + 1
                _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
            else
                _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
            end

            -- Consume Coin Rush Ticket if owned
            local cr_count = _G.stats.coin_rush_count or 0
            if cr_count > 0 then
                _G.stats.coin_rush_count = cr_count - 1
                self.coin_rush_active = true
            end
            save.saveStats(_G.stats)
        end

        if _G.active_companion == "dog" and _G.recordDogBreedPlayed and self.mode ~= "huge" then
            _G.recordDogBreedPlayed(_G.active_dog_breed)
        end
    end

    -- Clear lingering menu coin banners on new game
    local rend = _G.renderer or package.loaded["renderer"]
    if rend and rend.clearHeaderLogoMorph then
        rend.clearHeaderLogoMorph()
    end

    -- Trigger First Steps achievement
    if _G.unlockAchievement and self.mode ~= "huge" then
        _G.unlockAchievement("ach_first_game", self)
    end

    -- Time Attack: initialize timer after everything is set up if not loaded from save
    if mode == "timeattack" and not self.timeLeft then
        self.totalTime = tonumber(_G.time_attack_time) or 60.0
        self.timeLeft = self.totalTime
    end

    return self
end

function Game:saveGameState(force)
    if not force and self.animationTimer and self.animationTimer > 0 then
        self.savePending = true
        return
    end
    self.savePending = false

    if _G.stats then
        local maxVal = 0
        for x = 1, self.size do
            for y = 1, self.size do
                local cell = self.grid:cellContent(x, y)
                if cell and type(cell.value) == "number" and cell.value > maxVal then
                    maxVal = cell.value
                end
            end
        end
        local stats_changed = false
        if maxVal > (_G.stats.highest_tile or 0) then
            _G.stats.highest_tile = maxVal
            stats_changed = true
        end
        if self.score > (_G.stats.highest_score or 0) then
            _G.stats.highest_score = self.score
            stats_changed = true
        end
        if stats_changed or self.statsDirty then
            self.statsDirty = false
            save.saveStats(_G.stats)
        end
    end

    if self.highScoreDirty then
        self.highScoreDirty = false
        save.saveHighScore(self.highScore, self.mode)
    end

    local stateTable = {
        score = self.score,
        max_score_for_coins = self.max_score_for_coins,
        state = self.state,
        prevShieldState = self.prevShieldState,
        cursorX = self.cursorX,
        cursorY = self.cursorY,
        swapTarget = self.swapTarget,
        shield_mode = self.shield_mode,
        shield_index = self.shield_index,
        won = self.won,
        canUndo = self.canUndo,
        gridState = self.grid:saveState(),
        rngState = self.rng and self.rng:getState() or nil,
        undoHistory = self.undoHistory,
        powerups = self.powerups,
        milestonesReached = self.milestonesReached,
        runTime = self.runTime,
        undo_used_this_run = self.undo_used_this_run,
        swap_used_this_run = self.swap_used_this_run,
        powerups_used_this_run = self.powerups_used_this_run,
        coin_rush_active = self.coin_rush_active or false,
        second_chance_count = self.second_chance_count or 0,
        start_booster_val = self.start_booster_val,
        used_booster_this_run = self.used_booster_this_run
    }

    if self.mode == "timeattack" then
        stateTable.timeLeft = self.timeLeft
        stateTable.totalTime = self.totalTime
        stateTable.timesUp = self.timesUp
    end
    save.saveState(stateTable, self.mode)
end

function Game:flushSaveState()
    self:saveGameState(true)
end

function Game:addStartTiles()
    if _G.cheat_debug_layout == "Fill Board" then
        _G.cheat_debug_layout = "None"
        local val = 2
        for r = 1, 4 do
            for c = 1, 4 do
                if self.mode == "goose" and r == 4 and c == 4 then
                    local goose = Tile.new(c, r, "goose")
                    goose.isNew = true
                    self.grid:insertTile(goose)
                else
                    local tile = Tile.new(c, r, val)
                    tile.isNew = true
                    self.grid:insertTile(tile)
                    val = val * 2
                end
            end
        end
        return
    end

    if _G.cheat_debug_layout == "Two 1024s" then
        _G.cheat_debug_layout = "None"
        local tile1 = Tile.new(1, 1, 1024)
        tile1.isNew = true
        self.grid:insertTile(tile1)

        local tile2 = Tile.new(2, 1, 1024)
        tile2.isNew = true
        self.grid:insertTile(tile2)

        if self.mode == "goose" then
            local cell = self.grid:randomAvailableCell(self.rng)
            if cell then
                local goose = Tile.new(cell.x, cell.y, "goose")
                goose.isNew = true
                self.grid:insertTile(goose)
            end
        end
        return
    end

    local starting_tiles = 2

    if self.mode == "goose" then
        local cell = self.grid:randomAvailableCell(self.rng)
        if cell then
            local goose = Tile.new(cell.x, cell.y, "goose")
            goose.isNew = true
            self.grid:insertTile(goose)
        end
        starting_tiles = 1
    end

    if _G.cheat_start_1024_classic or _G.cheat_start_1024_plus then
        if self.grid:cellsAvailable() then
            local cell = self.grid:randomAvailableCell(self.rng)
            if cell then
                local tile = Tile.new(cell.x, cell.y, 1024)
                tile.isNew = true
                self.grid:insertTile(tile)
                starting_tiles = starting_tiles - 1
            end
        end
    end

    -- High-tile boosters
    local b512 = _G.stats and (_G.stats.start_512_count or 0) or 0
    local b256 = _G.stats and (_G.stats.start_256_count or 0) or 0
    local b128 = _G.stats and (_G.stats.start_128_count or 0) or 0
    local booster_val = 0
    local booster_key = nil
    if self.mode == "classic" then
        if b512 > 0 then
            booster_val = 512
            booster_key = "start_512_count"
        elseif b256 > 0 then
            booster_val = 256
            booster_key = "start_256_count"
        elseif b128 > 0 then
            booster_val = 128
            booster_key = "start_128_count"
        end
    end

    if booster_val > 0 and booster_key then
        if self.grid:cellsAvailable() then
            local cell = self.grid:randomAvailableCell(self.rng)
            if cell then
                local tile = Tile.new(cell.x, cell.y, booster_val)
                tile.isNew = true
                tile.is_booster = true
                tile.booster_val = booster_val
                tile.booster_spawn_t = love.timer.getTime()
                self.grid:insertTile(tile)
                self.start_booster_val = booster_val
                self.used_booster_this_run = true
                self.powerups_used_this_run = (self.powerups_used_this_run or 0) + 1
                if _G.achievements then
                    _G.achievements.powerups_used_this_run = self.powerups_used_this_run
                    save.saveAchievements(_G.achievements)
                end
                _G.stats[booster_key] = (_G.stats[booster_key] or 1) - 1
                if save and save.saveStats then save.saveStats(_G.stats) end
            end
        end
    end

    for _ = 1, starting_tiles do
        self:addRandomTile()
    end
end

function Game:addRandomTile()
    if self.grid:cellsAvailable() then
        local rand_val = self.rng and self.rng:random() or love.math.random()
        local value = rand_val < 0.9 and 2 or 4

        local cell = self.grid:randomAvailableCell(self.rng)
        if cell then
            local tile = Tile.new(cell.x, cell.y, value)
            tile.isNew = true
            self.grid:insertTile(tile)
        end
    end
end

function Game:prepareTiles()
    self.grid:eachCell(function(x, y, tile)
        if tile then
            tile.mergedFrom = nil
            tile.isNew = false
            tile.isMerged = false
            tile.undoSourcePosition = nil
            tile:savePosition()
        end
    end)
end

function Game:moveTile(tile, x, y)
    self.grid.cells[tile.x][tile.y] = nil
    tile:setPosition(x, y)
    self.grid.cells[x][y] = tile
end

-- Build traversal order based on direction
function Game:buildTraversals(direction)
    local traversalsX = {}
    local traversalsY = {}

    for i = 1, self.size do
        table.insert(traversalsX, i)
        table.insert(traversalsY, i)
    end

    -- If moving right, traverse right-to-left
    if vectors[direction].x == 1 then
        local reversed = {}
        for i = #traversalsX, 1, -1 do
            table.insert(reversed, traversalsX[i])
        end
        traversalsX = reversed
    end

    -- If moving down, traverse bottom-to-top
    if vectors[direction].y == 1 then
        local reversed = {}
        for i = #traversalsY, 1, -1 do
            table.insert(reversed, traversalsY[i])
        end
        traversalsY = reversed
    end

    return traversalsX, traversalsY
end

-- Find the farthest position a tile can move to
function Game:findFarthestPosition(x, y, direction)
    local vec = vectors[direction]
    local prevX, prevY = x, y
    local nextX, nextY = x + vec.x, y + vec.y

    while self.grid:withinBounds(nextX, nextY) and self.grid:cellAvailable(nextX, nextY) do
        prevX, prevY = nextX, nextY
        nextX = nextX + vec.x
        nextY = nextY + vec.y
    end

    return prevX, prevY, nextX, nextY
end

function Game:move(direction)
    if self.state == Game.STATE_LOST or self.state == Game.STATE_WON then
        return false
    end

    -- Save undo state before the move, but only apply it if the board actually changes
    local pendingUndoState = self.grid:saveState()
    local pendingUndoScore = self.score
    local pendingUndoRNG = self.rng and self.rng:getState() or love.math.getRandomState()
    local pendingUndoWon = self.won
    local pendingUndoGameState = self.state

    local traversalsX, traversalsY = self:buildTraversals(direction)
    local moved = false
    self.merged_this_move = false

    self:prepareTiles()

    for _, x in ipairs(traversalsX) do
        for _, y in ipairs(traversalsY) do
            local tile = self.grid:cellContent(x, y)
            if tile and tile.value ~= "goose" then
                local farthestX, farthestY, nextX, nextY = self:findFarthestPosition(x, y, direction)
                local nextTile = self.grid:cellContent(nextX, nextY)

                -- Can we merge with the next tile?
                if nextTile and nextTile.value == tile.value and nextTile.mergedFrom == nil then
                    self.merged_this_move = true
                    if _G.stats then
                        _G.stats.tiles_merged = (_G.stats.tiles_merged or 0) + 1
                    end
                    local merged = Tile.new(nextX, nextY, tile.value * 2)
                    merged.mergedFrom = {tile, nextTile}
                    merged.isMerged = true
                    merged.previousPosition = {x = tile.x, y = tile.y}

                    self.grid:insertTile(merged)
                    self.grid:removeTile(tile)

                    -- Update score
                    self.score = self.score + merged.value
                    if self.score > self.max_score_for_coins then
                        local coins_to_add = math.floor(self.score / 200) - math.floor(self.max_score_for_coins / 200)
                        if coins_to_add > 0 and _G.stats then
                            if _G.stats.purchased_items and _G.stats.purchased_items["coin_multiplier"] then
                                coins_to_add = coins_to_add * 2
                            end
                            if self.coin_rush_active then
                                coins_to_add = coins_to_add * 2
                            end
                            _G.stats.coins = (_G.stats.coins or 0) + coins_to_add
                            _G.stats.total_coins_earned = (_G.stats.total_coins_earned or 0) + coins_to_add
                            self.statsDirty = true
                            -- Coin Hoarder achievement unlocks at 10000 total lifetime coins
                            if (_G.stats.total_coins_earned or 0) >= 10000 and _G.unlockAchievement then
                                _G.unlockAchievement("ach_coin_hoarder")
                            end
                        end
                        self.max_score_for_coins = self.score
                    end
                    if self.score > self.highScore then
                        self.highScore = self.score
                        self.highScoreDirty = true
                    end

                    -- Check powerup milestone unlocks
                    if self.mode == "plus" and merged.value >= 256 then
                        local m_str = tostring(merged.value)
                        if not self.milestonesReached[m_str] then
                            self.milestonesReached[m_str] = true

                            local morph_text = nil
                            if merged.value == 256 then
                                self.powerups.undo = self.powerups.undo + 1
                                morph_text = "+1 UNDO"
                            elseif merged.value == 512 then
                                self.powerups.swap = self.powerups.swap + 1
                                morph_text = "+1 SWAP"
                            elseif merged.value == 1024 then
                                self.powerups.bomb = self.powerups.bomb + 1
                                morph_text = "+1 BOMB"
                            elseif merged.value >= 2048 then
                                self.powerups.undo = self.powerups.undo + 1
                                self.powerups.bomb = self.powerups.bomb + 1
                                self.powerups.swap = self.powerups.swap + 1
                                morph_text = "+1 ALL"
                            end

                            if morph_text then
                                local renderer = require("renderer")
                                if renderer and renderer.triggerHeaderLogoMorph then
                                    renderer.triggerHeaderLogoMorph(morph_text)
                                end
                            end
                        end
                    end

                    -- Check win condition
                    if merged.value == self.targetValue and self.state == Game.STATE_PLAYING and self.mode ~= "timeattack" then
                        self.won = true
                        self.state = Game.STATE_WON
                        local sound = require("sound")
                        sound.playVictory()
                        self:flushSaveState()
                    end

                    if self.mode == "classic" and merged.value >= 2048 and _G.unlockAchievement then
                        _G.unlockAchievement("ach_2048")
                    end

                    if merged.value >= 2048 and _G.active_companion == "cat" and _G.unlockAchievement and self.mode ~= "huge" then
                        _G.unlockAchievement("ach_purrfect_run")
                    end

                    if merged.value >= 512 and _G.unlockAchievement and self.mode ~= "huge" then
                        _G.unlockAchievement("ach_merge_512")
                    end

                    if merged.value >= 1024 and _G.unlockAchievement and self.mode ~= "huge" then
                        _G.unlockAchievement("ach_merge_1024")
                    end

                    if merged.value >= 4096 and _G.unlockAchievement and self.mode ~= "huge" then
                        _G.unlockAchievement("ach_4096")
                    end

                    if merged.value >= 1024 and (self.powerups_used_this_run or 0) == 0 and not self.used_booster_this_run and (self.start_booster_val or 0) == 0 and _G.unlockAchievement and self.mode ~= "huge" then
                        _G.unlockAchievement("ach_untouchable")
                    end

                    if self.mode == "plus" and merged.value >= 2048 and _G.unlockAchievement then
                        _G.unlockAchievement("ach_2048_plus")
                    end

                    if merged.value >= 2048 and (self.powerups_used_this_run or 0) == 0 and not self.used_booster_this_run and (self.start_booster_val or 0) == 0 and _G.unlockAchievement and self.mode ~= "huge" then
                        _G.unlockAchievement("ach_untouchable_2048")
                    end

                    if self.mode == "huge" and merged.value >= 2048 and _G.unlockAchievement then
                        _G.unlockAchievement("ach_huge_2048")
                    end
                    if self.mode == "nomercy" and merged.value >= 512 and _G.unlockAchievement then
                        _G.unlockAchievement("ach_nomercy_512")
                    end
                    if self.mode == "goose" and merged.value >= 2048 and _G.unlockAchievement then
                        _G.unlockAchievement("ach_goose_2048")
                    end

                    -- Trigger pet excitement on high merge
                    if merged.value >= 512 then
                        _G.pet_excited_timer = 2.0
                    end

                    if merged.value >= 8192 and _G.unlockAchievement and self.mode ~= "huge" then
                        _G.unlockAchievement("ach_merge_8192")
                    end

                    if merged.value >= 2048 and self.runTime and self.runTime <= 420 and not self.used_booster_this_run and (self.start_booster_val or 0) == 0 and _G.unlockAchievement and self.mode ~= "huge" then
                        _G.unlockAchievement("ach_speedrun_2048")
                    end

                    if self.mode == "plus" and merged.value >= 2048 and (self.powerups_used_this_run or 0) == 0 and _G.unlockAchievement then
                        _G.unlockAchievement("ach_hardcore_2048")
                    end


                    -- Add time attack merge bonus
                    if self.mode == "timeattack" and self.timeLeft then
                        local bonus = 0
                        if merged.value == 32 then
                            bonus = 2
                        elseif merged.value == 64 then
                            bonus = 4
                        elseif merged.value == 128 then
                            bonus = 6
                        elseif merged.value == 256 then
                            bonus = 8
                        elseif merged.value == 512 then
                            bonus = 15
                        elseif merged.value == 1024 then
                            bonus = 25
                        elseif merged.value >= 2048 then
                            bonus = 50
                        end
                        -- Special: hitting 2048 gives a massive bonus + achievement
                        if merged.value >= 2048 then
                            if _G.unlockAchievement then
                                _G.unlockAchievement("ach_timeattack_2048")
                            end
                        end
                        self.timeAttackBonus = (self.timeAttackBonus or 0) + bonus
                    end

                    moved = true
                else
                    -- Just move to farthest available position
                    if farthestX ~= x or farthestY ~= y then
                        self:moveTile(tile, farthestX, farthestY)
                        moved = true
                    end
                end
            end
        end
    end

    if moved then
        if _G.active_companion == "dog" and _G.recordDogBreedPlayed and self.mode ~= "huge" then
            _G.recordDogBreedPlayed(_G.active_dog_breed)
        end
        if _G.stats then
            _G.stats.moves_made = (_G.stats.moves_made or 0) + 1
            if self.score > (_G.stats.highest_score or 0) then
                _G.stats.highest_score = self.score
            end
        end
        -- Apply move time bonus
        if self.mode == "timeattack" and self.timeLeft and (self.timeAttackBonus or 0) > 0 then
            local cap = 30.0
            -- 2048 merge bypasses cap
            local merged_2048 = self.timeAttackBonus >= 50
            local bonus = merged_2048 and self.timeAttackBonus or math.min(self.timeAttackBonus, cap)
            self.timeLeft = math.min(self.totalTime, self.timeLeft + bonus)
            if self.timeLeft > 3.0 then
                self.lastCountdownSecond = nil
            end

            -- Show floating bonus text and flash timer
            self.timePopups = self.timePopups or {}
            table.insert(self.timePopups, {
                text = "+" .. tostring(math.floor(bonus)) .. "s",
                y_offset = 0,
                alpha = 1.0
            })
            self.timerFlashTimer = 0.3

            self.timeAttackBonus = 0
        end
        local undoTransitions = {}
        for x = 1, self.size do
            for y = 1, self.size do
                local c_tile = self.grid.cells[x][y]
                if c_tile then
                    if c_tile.mergedFrom and c_tile.mergedFrom[1] and c_tile.mergedFrom[2] then
                        local t1 = c_tile.mergedFrom[1]
                        local t2 = c_tile.mergedFrom[2]
                        local p1 = t1.previousPosition or (t1.x and t1.y and {x = t1.x, y = t1.y})
                        local p2 = t2.previousPosition or (t2.x and t2.y and {x = t2.x, y = t2.y})
                        if p1 then
                            table.insert(undoTransitions, {px = p1.x, py = p1.y, sx = x, sy = y})
                        end
                        if p2 then
                            table.insert(undoTransitions, {px = p2.x, py = p2.y, sx = x, sy = y})
                        end
                    elseif not c_tile.isNew then
                        local p = c_tile.previousPosition or (c_tile.x and c_tile.y and {x = c_tile.x, y = c_tile.y})
                        if p and (p.x ~= x or p.y ~= y) then
                            table.insert(undoTransitions, {px = p.x, py = p.y, sx = x, sy = y})
                        end
                    end
                end
            end
        end

        local pending = {
            gridState = pendingUndoState,
            score = pendingUndoScore,
            rng = pendingUndoRNG,
            won = pendingUndoWon,
            gameState = pendingUndoGameState,
            undoTransitions = undoTransitions
        }
        if _G.undo_mode == "unlimited" or self.mode == "plus" then
            table.insert(self.undoHistory, pending)
            if #self.undoHistory > 100 then
                table.remove(self.undoHistory, 1)
            end
            self.canUndo = true
        elseif _G.undo_mode == "classic" then
            self.undoHistory = { pending }
            self.canUndo = true
        else
            self.undoHistory = {}
            self.canUndo = false
        end

        self.animationDuration = 0.12
        if _G.animation_speed == "fast" then
            self.animationDuration = 0.06
        elseif _G.animation_speed == "instant" then
            self.animationDuration = 0
        elseif _G.animation_speed == "slow" then
            self.animationDuration = 0.24
        end

        if self.mode == "goose" then
            self:walkGoose()
        end
        self:addRandomTile()
        if self.mode == "nomercy" then
            self:addRandomTile()
        end
        if self.mode == "goose" then
            self.animationTimer = self.animationDuration * 2
        else
            self.animationTimer = self.animationDuration
        end
        if self.powerups_used_this_run == nil then
            self.powerups_used_this_run = 0
        end
        if _G.achievements and _G.achievements.powerups_used_this_run == nil then
            _G.achievements.powerups_used_this_run = 0
        end
        if _G.unlockAchievement and self.mode ~= "huge" then
            if self.score >= 1000 then _G.unlockAchievement("ach_score_1k") end
            if self.score >= 2000 then _G.unlockAchievement("ach_score_2k") end
            if self.score >= 5000 then _G.unlockAchievement("ach_score_5k") end
            if self.score >= 7500 then _G.unlockAchievement("ach_score_7k") end
            if self.score >= 10000 then _G.unlockAchievement("ach_score_10k") end
            if self.score >= 25000 then _G.unlockAchievement("ach_score_25k") end
            if self.score >= 50000 then _G.unlockAchievement("ach_score_50k") end
            if self.score >= 100000 then _G.unlockAchievement("ach_score_100k") end
            if self.score >= 250000 then _G.unlockAchievement("ach_score_250k") end
        end
        if not self:movesAvailable() and self.state ~= Game.STATE_WON then
            self.state = Game.STATE_LOST
            local sound = require("sound")
            sound.playGameOver()
            self:flushSaveState()
        else
            self.savePending = true
        end
    else
        self.grid:restoreState(pendingUndoState)
        self.score = pendingUndoScore
        self.moved = false
        return false
    end

    self.moved = moved
    return moved
end

function Game:walkGoose()
    local gooseTile = nil
    self.grid:eachCell(function(x, y, tile)
        if tile and tile.value == "goose" then
            gooseTile = tile
        end
    end)

    if not gooseTile then return end

    local adjacentEmpties = {}
    local dirs = {
        {x = -1, y = 0},
        {x = 1, y = 0},
        {x = 0, y = -1},
        {x = 0, y = 1}
    }
    for _, dir in ipairs(dirs) do
        local nx = gooseTile.x + dir.x
        local ny = gooseTile.y + dir.y
        if self.grid:withinBounds(nx, ny) and self.grid:cellAvailable(nx, ny) then
            table.insert(adjacentEmpties, {x = nx, y = ny})
        end
    end

    local target
    if #adjacentEmpties > 0 then
        target = adjacentEmpties[love.math.random(1, #adjacentEmpties)]
    else
        target = self.grid:randomAvailableCell()
    end

    if target then
        gooseTile:savePosition()
        self:moveTile(gooseTile, target.x, target.y)

        local dx = target.x - gooseTile.previousPosition.x
        local dy = target.y - gooseTile.previousPosition.y
        local dist = math.abs(dx) + math.abs(dy)

        if dist > 1 then
            gooseTile.move_anim = "flap"
        else
            local empties = #self.grid:getAvailableCells()
            if empties <= 5 or love.math.random() < 0.25 then
                gooseTile.move_anim = "run"
            else
                gooseTile.move_anim = "walk"
            end
        end
    end
end

function Game:movesAvailable()
    if self.grid:cellsAvailable() then
        return true
    end

    -- Check if any adjacent tiles can merge
    for x = 1, self.size do
        for y = 1, self.size do
            local tile = self.grid:cellContent(x, y)
            if tile then
                for dir = 0, 3 do
                    local vec = vectors[dir]
                    local nx, ny = x + vec.x, y + vec.y
                    local other = self.grid:cellContent(nx, ny)
                    if other and other.value == tile.value then
                        return true
                    end
                end
            end
        end
    end

    return false
end

function Game:undo()
    if _G.undo_mode == "disabled" and self.mode ~= "plus" then return end
    if not self.canUndo or #self.undoHistory == 0 then return end

    if self.mode == "plus" then
        if self.powerups.undo <= 0 then return end
        self.powerups.undo = self.powerups.undo - 1
        if _G.stats and (_G.stats.powerup_undo_count or 0) > 0 then
            _G.stats.powerup_undo_count = _G.stats.powerup_undo_count - 1
        end
        self.undo_used_this_run = (self.undo_used_this_run or 0) + 1
        if (self.undo_used_this_run or 0) >= 3 and (self.swap_used_this_run or 0) >= 3 and _G.unlockAchievement then
            _G.unlockAchievement("ach_tactician")
        end
    end

    self.powerups_used_this_run = (self.powerups_used_this_run or 0) + 1
    if _G.achievements then
        _G.achievements.powerups_used_this_run = self.powerups_used_this_run
        save.saveAchievements(_G.achievements)
    end
    if _G.stats then
        _G.stats.undos_used = (_G.stats.undos_used or 0) + 1
        save.saveStats(_G.stats)
    end

    local state = table.remove(self.undoHistory)
    if (_G.undo_mode == "classic" and self.mode ~= "plus") or #self.undoHistory == 0 then
        self.canUndo = false
    end
    if self.mode == "plus" and self.powerups.undo <= 0 then
        self.canUndo = false
    end

    -- Snapshot the current tiles before restoring the old grid
    local current_cells = {}
    for x = 1, self.size do
        current_cells[x] = {}
        for y = 1, self.size do
            current_cells[x][y] = self.grid.cells[x][y]
        end
    end

    self.grid:restoreState(state.gridState)
    self.score = state.score

    if state.rng then
        if self.rng then
            self.rng:setState(state.rng)
        else
            love.math.setRandomState(state.rng)
        end
    end

    if state.won ~= nil then self.won = state.won end
    if state.gameState ~= nil then
        self.state = state.gameState
    else
        -- Reset game state if we were lost/won
        if self.state == Game.STATE_LOST then
            self.state = self.won and Game.STATE_ENDLESS or Game.STATE_PLAYING
        elseif self.state == Game.STATE_WON then
            self.state = Game.STATE_PLAYING
            self.won = false
        end
    end

    -- Clear animation states from newly restored grid
    self.grid:eachCell(function(x, y, tile)
        if tile then
            tile.isNew = false
            tile.isMerged = false
            tile.previousPosition = nil
            tile.undoSourcePosition = nil
        end
    end)

    -- Apply reverse animation transitions
    if state.undoTransitions and #state.undoTransitions > 0 then
        for _, trans in ipairs(state.undoTransitions) do
            local r_t = self.grid:cellContent(trans.px, trans.py)
            if r_t then
                r_t.undoSourcePosition = {x = trans.sx, y = trans.sy}
            end
        end
    else
        for x = 1, self.size do
            for y = 1, self.size do
                local c_tile = current_cells[x][y]
                if c_tile then
                    if c_tile.mergedFrom and c_tile.mergedFrom[1] and c_tile.mergedFrom[2] then
                        local t1 = c_tile.mergedFrom[1]
                        local t2 = c_tile.mergedFrom[2]
                        local p1 = t1.previousPosition or (t1.x and t1.y and {x = t1.x, y = t1.y})
                        local p2 = t2.previousPosition or (t2.x and t2.y and {x = t2.x, y = t2.y})
                        if p1 then
                            local r_t1 = self.grid:cellContent(p1.x, p1.y)
                            if r_t1 then r_t1.undoSourcePosition = {x = x, y = y} end
                        end
                        if p2 then
                            local r_t2 = self.grid:cellContent(p2.x, p2.y)
                            if r_t2 then r_t2.undoSourcePosition = {x = x, y = y} end
                        end
                    elseif not c_tile.isNew then
                        local p = c_tile.previousPosition or (c_tile.x and c_tile.y and {x = c_tile.x, y = c_tile.y})
                        if p then
                            local r_t = self.grid:cellContent(p.x, p.y)
                            if r_t then r_t.undoSourcePosition = {x = x, y = y} end
                        end
                    end
                end
            end
        end
    end

    self.animationDuration = 0.12
    if _G.animation_speed == "fast" then
        self.animationDuration = 0.06
    elseif _G.animation_speed == "instant" then
        self.animationDuration = 0
    elseif _G.animation_speed == "slow" then
        self.animationDuration = 0.24
    end

    -- Trigger animation timer
    self.animationTimer = self.animationDuration

    self:saveGameState()
end

function Game:continueGame()
    -- Endless mode continuation
    if self.state == Game.STATE_WON then
        self.state = Game.STATE_ENDLESS
        self:saveGameState()
    end
end

function Game:restart()
    self.rng = love.math.newRandomGenerator(math.floor(love.timer.getTime() * 1000) + love.math.random(1, 100000))
    self.grid:clear()
    self.score = 0
    self.max_score_for_coins = 0
    self.state = Game.STATE_PLAYING
    self.won = false
    self.canUndo = false
    self.undoHistory = {}
    self.animationTimer = 0
    if self.mode == "plus" then
        local initial_powerups = _G.cheat_max_powerups and 99 or 0
        local extra_undo, extra_bomb, extra_swap = 0, 0, 0
        if _G.stats then
            local pi = _G.stats.purchased_items or {}
            extra_undo = (pi["extra_undo"] or 0) + (_G.stats.powerup_undo_count or 0)
            extra_bomb = (pi["extra_bomb"] or 0) + (_G.stats.powerup_bomb_count or 0)
            extra_swap = (pi["extra_swap"] or 0) + (_G.stats.powerup_swap_count or 0)
        end
        self.powerups = { undo = initial_powerups + extra_undo, bomb = initial_powerups + extra_bomb, swap = initial_powerups + extra_swap }
        self.milestonesReached = {}
    end
    -- Reset Time Attack timer
    if self.mode == "timeattack" then
        self.totalTime = tonumber(_G.time_attack_time) or 60.0
        self.timeLeft = self.totalTime
        self.timeAttackBonus = 0
        self.shownUrgentWarning = false
        self.timesUp = false
        self.timePopups = {}
        self.timerFlashTimer = 0
        self.timerPopTimer = 0
        self.lastCountdownSecond = nil
    end
    self.powerups_used_this_run = 0
    if _G.achievements then
        _G.achievements.powerups_used_this_run = 0
        save.saveAchievements(_G.achievements)
    end
    self.used_booster_this_run = false
    self.runTime = 0
    self.undo_used_this_run = 0
    self.swap_used_this_run = 0
    self.second_chance_count = (_G.stats and _G.stats.second_chance_count) or 0
    self.start_booster_val = nil
    self:addStartTiles()
    -- Consume Coin Rush Ticket if owned
    self.coin_rush_active = false
    if _G.stats then
        local cr_count = _G.stats.coin_rush_count or 0
        if cr_count > 0 then
            _G.stats.coin_rush_count = cr_count - 1
            self.coin_rush_active = true
        end
    end
    if _G.stats then
        _G.stats.games_played = (_G.stats.games_played or 0) + 1
        if self.mode == "classic" then
            _G.stats.classic_games = (_G.stats.classic_games or 0) + 1
        elseif self.mode == "plus" then
            _G.stats.plus_games = (_G.stats.plus_games or 0) + 1
        elseif self.mode == "timeattack" then
            _G.stats.timeattack_games = (_G.stats.timeattack_games or 0) + 1
            _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
        elseif self.mode == "huge" then
            _G.stats.huge_games = (_G.stats.huge_games or 0) + 1
            _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
        elseif self.mode == "nomercy" then
            _G.stats.nomercy_games = (_G.stats.nomercy_games or 0) + 1
            _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
        elseif self.mode == "goose" then
            _G.stats.goose_games = (_G.stats.goose_games or 0) + 1
            _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
        else
            _G.stats.arcade_games = (_G.stats.arcade_games or 0) + 1
        end
        save.saveStats(_G.stats)
    end
    self:saveGameState()
end

function Game:togglePause()
    if self.state == Game.STATE_PLAYING or self.state == Game.STATE_ENDLESS then
        self.prevState = self.state
        self.state = Game.STATE_PAUSED
        self:flushSaveState()
    elseif self.state == Game.STATE_PAUSED then
        self.state = self.prevState or (self.won and Game.STATE_ENDLESS or Game.STATE_PLAYING)
    else
        self:restart()
    end
end

function Game:cancelPause()
    if self.state == Game.STATE_PAUSED then
        self.state = self.prevState or (self.won and Game.STATE_ENDLESS or Game.STATE_PLAYING)
    end
end

-- ============================================================================
-- Targeting / Powerups
-- ============================================================================

function Game:startBombTargeting()
    if self.mode ~= "plus" or self.powerups.bomb <= 0 then return end
    if not self:isPlaying() then return end
    self.state = Game.STATE_TARGETING_BOMB
    self.cursorX = 2
    self.cursorY = 2
end

function Game:startSwapTargeting()
    if self.mode ~= "plus" or self.powerups.swap <= 0 then return end
    if not self:isPlaying() then return end
    self.state = Game.STATE_TARGETING_SWAP_1
    self.cursorX = 2
    self.cursorY = 2
    self.swapTarget = nil
end

function Game:moveCursor(dx, dy)
    local nx = self.cursorX + dx
    local ny = self.cursorY + dy
    if nx >= 1 and nx <= self.size and ny >= 1 and ny <= self.size then
        self.cursorX = nx
        self.cursorY = ny
    end
end

function Game:cancelTargeting()
    self.state = self.won and Game.STATE_ENDLESS or Game.STATE_PLAYING
    self.swapTarget = nil
end

function Game:confirmTarget()
    local cx, cy = self.cursorX, self.cursorY

    if self.state == Game.STATE_TARGETING_BOMB then
        if self.grid.cells[cx][cy] then
            -- Delete the tile
            local pending = {
                gridState = self.grid:saveState(),
                score = self.score,
                rng = (self.rng and self.rng:getState()) or love.math.getRandomState(),
                won = self.won,
                gameState = self.state
            }
            if _G.undo_mode == "unlimited" or self.mode == "plus" then
                table.insert(self.undoHistory, pending)
                if #self.undoHistory > 100 then
                    table.remove(self.undoHistory, 1)
                end
                self.canUndo = true
            elseif _G.undo_mode == "classic" then
                self.undoHistory = { pending }
                self.canUndo = true
            else
                self.undoHistory = {}
                self.canUndo = false
            end

            local t = self.grid.cells[cx][cy]
            self.bombAnimation = {x = cx, y = cy, tileValue = t.value, timer = 0.15, duration = 0.15}

            self.grid.cells[cx][cy] = nil
            self.powerups.bomb = self.powerups.bomb - 1
            if _G.stats then
                _G.stats.bombs_used = (_G.stats.bombs_used or 0) + 1
                if (_G.stats.powerup_bomb_count or 0) > 0 then
                    _G.stats.powerup_bomb_count = _G.stats.powerup_bomb_count - 1
                end
                if save and save.saveStats then save.saveStats(_G.stats) end
            end

            _G.achievements.bombs_used = (_G.achievements.bombs_used or 0) + 1
            if _G.unlockAchievement then
                if _G.achievements.bombs_used >= 1 then
                    _G.unlockAchievement("ach_first_bomb")
                end
                if _G.achievements.bombs_used >= 10 then
                    _G.unlockAchievement("ach_demolition")
                end
            end

            self.powerups_used_this_run = (self.powerups_used_this_run or 0) + 1
            if _G.achievements then
                _G.achievements.powerups_used_this_run = self.powerups_used_this_run
                save.saveAchievements(_G.achievements)
            end

            self.state = self.won and Game.STATE_ENDLESS or Game.STATE_PLAYING
            self:saveGameState()
        end
    elseif self.state == Game.STATE_TARGETING_SWAP_1 then
        if self.grid.cells[cx][cy] then
            self.swapTarget = {x = cx, y = cy}
            self.state = Game.STATE_TARGETING_SWAP_2
        end
    elseif self.state == Game.STATE_TARGETING_SWAP_2 then
        if (self.swapTarget.x ~= cx or self.swapTarget.y ~= cy) then
            local pending = {
                gridState = self.grid:saveState(),
                score = self.score,
                rng = (self.rng and self.rng:getState()) or love.math.getRandomState(),
                won = self.won,
                gameState = self.state,
                undoTransitions = {
                    {px = self.swapTarget.x, py = self.swapTarget.y, sx = cx, sy = cy},
                    {px = cx, py = cy, sx = self.swapTarget.x, sy = self.swapTarget.y}
                }
            }
            if _G.undo_mode == "unlimited" or self.mode == "plus" then
                table.insert(self.undoHistory, pending)
                if #self.undoHistory > 100 then
                    table.remove(self.undoHistory, 1)
                end
                self.canUndo = true
            elseif _G.undo_mode == "classic" then
                self.undoHistory = { pending }
                self.canUndo = true
            else
                self.undoHistory = {}
                self.canUndo = false
            end

            local t1 = self.grid.cells[self.swapTarget.x][self.swapTarget.y]
            local t2 = self.grid.cells[cx][cy]

            -- Swap them in grid
            self.grid.cells[self.swapTarget.x][self.swapTarget.y] = t2
            self.grid.cells[cx][cy] = t1

            -- Start animation
            self.swapAnimation = {
                t1 = t1 and {val = t1.value, startX = self.swapTarget.x, startY = self.swapTarget.y, endX = cx, endY = cy} or nil,
                t2 = t2 and {val = t2.value, startX = cx, startY = cy, endX = self.swapTarget.x, endY = self.swapTarget.y} or nil,
                t1Ref = t1,
                t2Ref = t2,
                timer = 0.20,
                duration = 0.20
            }
            if t1 then t1.isSwapping = true end
            if t2 then t2.isSwapping = true end

            -- Update tile coordinates
            if t1 then t1:setPosition(cx, cy) end
            if t2 then t2:setPosition(self.swapTarget.x, self.swapTarget.y) end

            self.powerups.swap = self.powerups.swap - 1
            self.swap_used_this_run = (self.swap_used_this_run or 0) + 1
            if (self.undo_used_this_run or 0) >= 3 and (self.swap_used_this_run or 0) >= 3 and _G.unlockAchievement then
                _G.unlockAchievement("ach_tactician")
            end
            if _G.stats then
                _G.stats.swaps_used = (_G.stats.swaps_used or 0) + 1
                if (_G.stats.powerup_swap_count or 0) > 0 then
                    _G.stats.powerup_swap_count = _G.stats.powerup_swap_count - 1
                end
                if save and save.saveStats then save.saveStats(_G.stats) end
            end
            self.swapTarget = nil



            self.powerups_used_this_run = (self.powerups_used_this_run or 0) + 1
            if _G.achievements then
                _G.achievements.powerups_used_this_run = self.powerups_used_this_run
                save.saveAchievements(_G.achievements)
            end

            self.state = self.won and Game.STATE_ENDLESS or Game.STATE_PLAYING
            self:saveGameState()
        else
            -- Cannot swap with self; cancel
            self.swapTarget = nil
            self.state = Game.STATE_TARGETING_SWAP_1
        end
    end
end

function Game:update(dt)
    if self.state == Game.STATE_PLAYING or self.state == Game.STATE_ENDLESS then
        self.runTime = (self.runTime or 0) + dt
        if _G.stats then
            _G.stats.time_played = (_G.stats.time_played or 0) + dt
        end
    end


    if self.animationTimer > 0 then
        self.animationTimer = self.animationTimer - dt
        if self.animationTimer <= 0 then
            self.animationTimer = 0
            if self.savePending then
                self:flushSaveState()
            end
        end
    end

    -- Time Attack: countdown
    if self.mode == "timeattack" and self.timeLeft ~= nil then
        if self.state == Game.STATE_PLAYING or self.state == Game.STATE_ENDLESS then
            self.timeLeft = self.timeLeft - dt
            if self.timeLeft <= 10 and not self.shownUrgentWarning then
                self.shownUrgentWarning = true
                -- Toast is shown by renderer's pulse; no explicit toast here to avoid spam
            end
            if self.timeLeft > 0 and self.timeLeft <= 3.0 then
                local sec = math.ceil(self.timeLeft)
                if sec >= 1 and sec <= 3 and sec ~= self.lastCountdownSecond then
                    self.lastCountdownSecond = sec
                    self.timerPopTimer = 0.25
                    local snd = require("sound")
                    if snd and snd.playCountdown then
                        snd.playCountdown(sec)
                    end
                end
            end
            if self.timeLeft <= 0 then
                self.timeLeft = 0
                self.state = Game.STATE_LOST
                self.timesUp = true  -- flag for renderer to show "Time's Up!"
                self.lastCountdownSecond = nil
                local sound = require("sound")
                sound.playGameOver()
                self:saveGameState()  -- saves high score only, saveGameState returns early for timeattack
                save.saveHighScore(self.highScore, self.mode)
            end
        end
    end

    if self.bombAnimation then
        self.bombAnimation.timer = self.bombAnimation.timer - dt
        if self.bombAnimation.timer <= 0 then
            self.bombAnimation = nil
        end
    end

    if self.swapAnimation then
        self.swapAnimation.timer = self.swapAnimation.timer - dt
        if self.swapAnimation.timer <= 0 then
            if self.swapAnimation.t1Ref then self.swapAnimation.t1Ref.isSwapping = false end
            if self.swapAnimation.t2Ref then self.swapAnimation.t2Ref.isSwapping = false end
            self.swapAnimation = nil
        end
    end

    -- Update floating time popups
    if self.timePopups then
        local scale = _G.scale or 1
        for i = #self.timePopups, 1, -1 do
            local p = self.timePopups[i]
            p.y_offset = p.y_offset - dt * 35 * scale
            p.alpha = p.alpha - dt * 1.8
            if p.alpha <= 0 then
                table.remove(self.timePopups, i)
            end
        end
    end

    -- Update timer flash
    if self.timerFlashTimer and self.timerFlashTimer > 0 then
        self.timerFlashTimer = self.timerFlashTimer - dt
        if self.timerFlashTimer < 0 then
            self.timerFlashTimer = 0
        end
    end
    if self.timerPopTimer and self.timerPopTimer > 0 then
        self.timerPopTimer = self.timerPopTimer - dt
        if self.timerPopTimer < 0 then
            self.timerPopTimer = 0
        end
    end

    if self.floatingNotifications then
        for i = #self.floatingNotifications, 1, -1 do
            local n = self.floatingNotifications[i]
            n.timer = n.timer - dt
            if n.timer <= 0 then
                table.remove(self.floatingNotifications, i)
            end
        end
    end
end

function Game:addFloatingNotification(text, col, row)
    -- Disabled on-board floating text to keep tiles 100% clean for power users
end

function Game:getAnimationProgress()
    if self.animationDuration <= 0 then return 1 end
    local progress = 1 - (self.animationTimer / self.animationDuration)
    return math.max(0, math.min(1, progress))
end

function Game:isAnimating()
    return self.animationTimer > 0
end

function Game:startShieldTargeting()
    if self.mode == "nomercy" then
        local renderer = require("renderer")
        if renderer and renderer.showToast then
            renderer.showToast("No Shield in No Mercy!")
        end
        return
    end
    if self.timesUp or (self.mode == "timeattack" and self.timeLeft and self.timeLeft <= 0) then
        local renderer = require("renderer")
        if renderer and renderer.showToast then
            renderer.showToast("Cannot use Shield when time is up!")
        end
        return
    end
    local count = self.second_chance_count or 0
    if count <= 0 then
        local sound = require("sound")
        local renderer = require("renderer")
        if renderer and renderer.showToast then
            renderer.showToast("No Second Chance Shield for this game!")
        end
        return
    end
    self.prevShieldState = self.state
    self.state = Game.STATE_TARGETING_SHIELD
    self.shield_mode = "row"
    self.shield_index = 1
end

function Game:moveShieldSelection(dir)
    local sound = require("sound")
    if dir == "up" then
        if self.shield_mode ~= "row" then
            self.shield_mode = "row"
        else
            self.shield_index = self.shield_index - 1
            if self.shield_index < 1 then self.shield_index = self.size end
        end
        if sound and sound.playMenuMove then sound.playMenuMove() end
    elseif dir == "down" then
        if self.shield_mode ~= "row" then
            self.shield_mode = "row"
        else
            self.shield_index = self.shield_index + 1
            if self.shield_index > self.size then self.shield_index = 1 end
        end
        if sound and sound.playMenuMove then sound.playMenuMove() end
    elseif dir == "left" then
        if self.shield_mode ~= "col" then
            self.shield_mode = "col"
        else
            self.shield_index = self.shield_index - 1
            if self.shield_index < 1 then self.shield_index = self.size end
        end
        if sound and sound.playMenuMove then sound.playMenuMove() end
    elseif dir == "right" then
        if self.shield_mode ~= "col" then
            self.shield_mode = "col"
        else
            self.shield_index = self.shield_index + 1
            if self.shield_index > self.size then self.shield_index = 1 end
        end
        if sound and sound.playMenuMove then sound.playMenuMove() end
    end
end

function Game:confirmShieldTarget()
    if self.state ~= Game.STATE_TARGETING_SHIELD then return end
    local count = self.second_chance_count or 0
    if count <= 0 then
        self:cancelShieldTargeting()
        return
    end

    local sound = require("sound")
    local renderer = require("renderer")

    -- Save undo snapshot
    local pending = {
        gridState = self.grid:saveState(),
        score = self.score,
        rng = (self.rng and self.rng:getState()) or love.math.getRandomState(),
        won = self.won,
        gameState = self.prevShieldState or self.state
    }
    if _G.undo_mode == "unlimited" or self.mode == "plus" then
        table.insert(self.undoHistory, pending)
        if #self.undoHistory > 100 then
            table.remove(self.undoHistory, 1)
        end
        self.canUndo = true
    elseif _G.undo_mode == "classic" then
        self.undoHistory = { pending }
        self.canUndo = true
    else
        self.undoHistory = {}
        self.canUndo = false
    end

    -- Clear chosen row or column
    local cleared = 0
    if self.shield_mode == "row" then
        local y = self.shield_index
        for x = 1, self.size do
            local cell = self.grid.cells[x] and self.grid.cells[x][y]
            if cell and cell.value ~= "goose" then
                self.grid.cells[x][y] = nil
                cleared = cleared + 1
            end
        end
    else
        local x = self.shield_index
        if self.grid.cells[x] then
            for y = 1, self.size do
                local cell = self.grid.cells[x][y]
                if cell and cell.value ~= "goose" then
                    self.grid.cells[x][y] = nil
                    cleared = cleared + 1
                end
            end
        end
    end

    -- Deduct 1 charge
    self.second_chance_count = math.max(0, count - 1)
    if _G.stats then
        _G.stats.second_chance_count = math.max(0, (_G.stats.second_chance_count or 0) - 1)
        if save and save.saveStats then save.saveStats(_G.stats) end
    end

    if _G.unlockAchievement then
        _G.unlockAchievement("ach_first_shield")
    end

    if sound and sound.playBomb then sound.playBomb() end
    local rend = _G.renderer or package.loaded["renderer"]
    if rend and rend.showToast then
        local lbl = (self.shield_mode == "row" and "Row " or "Column ") .. tostring(self.shield_index)
        rend.showToast("Shield Cleared " .. lbl .. "!")
    end

    -- Return to active gameplay
    self.state = self.won and Game.STATE_ENDLESS or Game.STATE_PLAYING
    self:saveGameState()
end

function Game:cancelShieldTargeting()
    if self.state == Game.STATE_TARGETING_SHIELD then
        local fallback = self.won and Game.STATE_ENDLESS or (self:movesAvailable() and Game.STATE_PLAYING or Game.STATE_LOST)
        self.state = self.prevShieldState or fallback
        self:saveGameState()
    end
end

function Game:isGameOver()
    if self.state == Game.STATE_LOST then
        return true
    end
    if self.mode == "timeattack" and (self.timesUp or (self.timeLeft and self.timeLeft <= 0)) then
        return true
    end
    return false
end

function Game:isPlaying()
    if self:isGameOver() then
        return false
    end
    return self.state == Game.STATE_PLAYING or self.state == Game.STATE_ENDLESS or
           self.state == Game.STATE_TARGETING_BOMB or self.state == Game.STATE_TARGETING_SWAP_1 or
           self.state == Game.STATE_TARGETING_SWAP_2 or self.state == Game.STATE_TARGETING_SHIELD
end

return Game
