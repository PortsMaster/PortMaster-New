# wipes.py - a set of simple screen wipes (in and out)
# Copyright 2004 Joe Wreschnig <piman@sacredchao.net>
# Released under the terms of the GNU GPL v2.
__revision__ = "$Id: wipes.py 286 2004-09-04 03:51:59Z piman $"

import random
from pygame import display, draw, time, Rect, Surface
from itertools import chain

c = time.Clock()

# Flipping the whole display once per line is cheap on the desktop
# hardware this was written for, but can block on vsync per call on a
# KMS/DRM display pipeline; batching several lines per display.update()
# call keeps the same visual effect with far fewer display flips.
UPDATE_BATCH = 16

def _flush(rects):
    if rects:
        display.update(rects)
        del rects[:]

def line_out_l2r():
    screen = display.get_surface()
    w, h = screen.get_size()
    rects = []
    for x in chain(range(0, w, 2), range(w - 1, 0, -2)):
        rects.append(draw.line(screen, [0, 0, 0], [x, 0], [x, h]))
        if len(rects) >= UPDATE_BATCH: _flush(rects)
        c.tick(700)
    _flush(rects)

def line_out_r2l():
    screen = display.get_surface()
    w, h = screen.get_size()
    rects = []
    for x in chain(range(w - 1, 0, -2), range(0, w, 2)):
        rects.append(draw.line(screen, [0, 0, 0], [x, 0], [x, h]))
        if len(rects) >= UPDATE_BATCH: _flush(rects)
        c.tick(700)
    _flush(rects)

def line_out_t2b():
    screen = display.get_surface()
    w, h = screen.get_size()
    rects = []
    for y in chain(range(0, h, 2), range(h - 1, 0, -2)):
        rects.append(draw.line(screen, [0, 0, 0], [0, y], [w, y]))
        if len(rects) >= UPDATE_BATCH: _flush(rects)
        c.tick(700)
    _flush(rects)

def line_out_b2t():
    screen = display.get_surface()
    w, h = screen.get_size()
    rects = []
    for y in chain(range(h - 1, 0, -2), range(0, h, 2)):
        rects.append(draw.line(screen, [0, 0, 0], [0, y], [w, y]))
        if len(rects) >= UPDATE_BATCH: _flush(rects)
        c.tick(700)
    _flush(rects)

def line_in_l2r(surf):
    screen = display.get_surface()
    w, h = screen.get_size()
    rects = []
    for x in chain(range(0, w, 2), range(w - 1, 0, -2)):
        rects.append(screen.blit(surf, [x, 0, 1, h], [x, 0, 1, h]))
        if len(rects) >= UPDATE_BATCH: _flush(rects)
        c.tick(700)
    _flush(rects)

def line_in_r2l(surf):
    screen = display.get_surface()
    w, h = screen.get_size()
    rects = []
    for x in chain(range(w - 1, 0, -2), range(0, w, 2)):
        rects.append(screen.blit(surf, [x, 0, 1, h], [x, 0, 1, h]))
        if len(rects) >= UPDATE_BATCH: _flush(rects)
        c.tick(700)
    _flush(rects)

def line_in_t2b(surf):
    screen = display.get_surface()
    w, h = screen.get_size()
    rects = []
    for y in chain(range(0, h, 2), range(h - 1, 0, -2)):
        rects.append(screen.blit(surf, [0, y, w, 1], [0, y, w, 1]))
        if len(rects) >= UPDATE_BATCH: _flush(rects)
        c.tick(700)
    _flush(rects)

def line_in_b2t(surf):
    screen = display.get_surface()
    w, h = screen.get_size()
    rects = []
    for y in chain(range(h - 1, 0, -2), range(0, h, 2)):
        rects.append(screen.blit(surf, [0, y, w, 1], [0, y, w, 1]))
        if len(rects) >= UPDATE_BATCH: _flush(rects)
        c.tick(700)
    _flush(rects)

OUTS = [line_out_l2r, line_out_r2l, line_out_b2t, line_out_t2b]
INS = [line_in_l2r, line_in_r2l, line_in_b2t, line_in_t2b]

def wipe_out(): random.choice(OUTS)()
def wipe_in(s): random.choice(INS)(s)
