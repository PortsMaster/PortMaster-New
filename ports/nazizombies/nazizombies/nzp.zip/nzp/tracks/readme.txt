the tracks directory contains tracks from the OST in-use by the game.
they are not the highest quality available. the MP3s are exclusive to
PSP so they have a higher level of compression applied. it is planned
to release the source tracks in the future, when the track list is
fully complete.

- motolegacy (30 jun 2021, edited 25 mar 2023)
