https://gamebanana.com/mods/6814
Made by JasperCarmack

02/02/2020 
==============================================
Sky_Waldon01 VMT, VTF and TGAs
==============================================

ABOUT THIS FILE:

A gorgeous afternoon sky.

Feel free to use for your own projects and mods! Credit not required but is always appreciated.

Commercial use restricted; rendered on an unlicenced copy of Terragen Classic, so if you go using this for a retail game, it ain't me you have to worry about, Planetside would probably want to have a word with you.

ENJOY!