/* history.h */

#pragma once

#include "base.h"

void history(SDL_Window *screen,uint8_t *state,uint8_t *grapset,uint8_t *fullscreen);
