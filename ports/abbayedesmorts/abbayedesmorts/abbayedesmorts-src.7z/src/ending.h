/* ending.h */

#pragma once

#include "base.h"

void ending (SDL_Window *screen,uint8_t *state);
