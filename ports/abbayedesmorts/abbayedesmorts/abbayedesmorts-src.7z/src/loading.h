/* loading.h */

#pragma once

#include "base.h"

void loadingmusic(Mix_Music *bso[],Mix_Chunk *fx[]);
void loaddata(uint stagedata[][22][32],int enemydata[][7][15]);
