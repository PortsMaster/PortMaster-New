/* gameover.h */

#pragma once

#include "base.h"

void gameover(SDL_Window *screen,uint8_t *state);
